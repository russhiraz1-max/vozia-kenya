// API Configuration
const API_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:8080/api' 
    : 'https://vozia-kenya-api.onrender.com/api';

// Global variables
let currentUser = null;
let authToken = null;
let currentPage = 'feed';
let currentConversationId = null;
let typingTimeout = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
});

// Check if user is logged in
function checkAuth() {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (savedToken && savedUser) {
        authToken = savedToken;
        currentUser = JSON.parse(savedUser);
        showMainApp();
        loadPage('feed');
    } else {
        showAuthScreen();
    }
}

// Show auth screen
function showAuthScreen() {
    document.getElementById('auth-screen').style.display = 'flex';
    document.getElementById('main-app').style.display = 'none';
}

// Show main app
function showMainApp() {
    document.getElementById('auth-screen').style.display = 'none';
    document.getElementById('main-app').style.display = 'block';
}

// Setup event listeners
function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Signup form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
    
    // Show signup card
    const showSignup = document.getElementById('show-signup');
    if (showSignup) {
        showSignup.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelector('.auth-card').style.display = 'none';
            document.getElementById('signup-card').style.display = 'block';
        });
    }
    
    // Show login card
    const showLogin = document.getElementById('show-login');
    if (showLogin) {
        showLogin.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('signup-card').style.display = 'none';
            document.querySelector('.auth-card').style.display = 'block';
        });
    }
    
    // Navigation buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const page = btn.dataset.page;
            if (page) {
                loadPage(page);
            }
        });
    });
    
    // Create post button
    const createPostBtn = document.getElementById('submit-post-btn');
    if (createPostBtn) {
        createPostBtn.addEventListener('click', handleCreatePost);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            authToken = data.session_token;
            currentUser = data.user;
            localStorage.setItem('token', authToken);
            localStorage.setItem('user', JSON.stringify(currentUser));
            showMainApp();
            loadPage('feed');
        } else {
            alert(data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Connection error. Please try again.');
    }
}

// Handle signup
async function handleSignup(e) {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const full_name = document.getElementById('signup-fullname').value;
    const phone_number = document.getElementById('signup-phone').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password, full_name, phone_number })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Account created! Please check your email to verify.');
            document.getElementById('signup-card').style.display = 'none';
            document.querySelector('.auth-card').style.display = 'block';
        } else {
            alert(data.error || 'Signup failed');
        }
    } catch (error) {
        console.error('Signup error:', error);
        alert('Connection error. Please try again.');
    }
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    authToken = null;
    currentUser = null;
    showAuthScreen();
}

// Load page
async function loadPage(page) {
    currentPage = page;
    const pageContent = document.getElementById('page-content');
    
    // Update active nav button
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.page === page) {
            btn.classList.add('active');
        }
    });
    
    // Load appropriate page content
    switch(page) {
        case 'feed':
            await loadFeedPage();
            break;
        case 'explore':
            await loadExplorePage();
            break;
        case 'profile':
            await loadProfilePage(currentUser?.username);
            break;
        case 'notifications':
            await loadNotificationsPage();
            break;
        case 'dms':
            await loadDMsPage();
            break;
        default:
            await loadFeedPage();
    }
}

// Load feed page
async function loadFeedPage() {
    const pageContent = document.getElementById('page-content');
    
    // Fetch feed HTML
    const response = await fetch('feed.html');
    const html = await response.text();
    pageContent.innerHTML = html;
    
    // Load feed data
    await loadFeed();
    await loadStories();
    
    // Setup story creation
    const addStoryBtn = document.querySelector('.add-story-btn');
    if (addStoryBtn) {
        addStoryBtn.addEventListener('click', showCreateStoryModal);
    }
}

// Load feed posts
async function loadFeed() {
    try {
        const response = await fetch(`${API_URL}/feed`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        const feedContainer = document.getElementById('posts-feed');
        if (!feedContainer) return;
        
        if (data.posts && data.posts.length > 0) {
            feedContainer.innerHTML = data.posts.map(post => renderPost(post)).join('');
            attachPostEventListeners();
        } else {
            feedContainer.innerHTML = '<div class="loading-spinner">No posts yet. Follow some users!</div>';
        }
    } catch (error) {
        console.error('Load feed error:', error);
    }
}

// Load stories
async function loadStories() {
    try {
        const response = await fetch(`${API_URL}/stories`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        const storiesBar = document.getElementById('stories-bar');
        if (!storiesBar) return;
        
        // Keep the "Your story" element and add others
        const yourStoryHtml = storiesBar.querySelector('.story-ring')?.outerHTML || '';
        
        let storiesHtml = yourStoryHtml;
        if (data.stories_feed) {
            data.stories_feed.forEach(user => {
                if (user.stories.length > 0) {
                    storiesHtml += `
                        <div class="story-ring" data-user-id="${user.user_id}" data-stories='${JSON.stringify(user.stories)}'>
                            <div class="story-avatar">
                                <img src="${user.avatar_url || 'https://via.placeholder.com/70'}" alt="${user.username}">
                            </div>
                            <span class="story-username">${user.username}</span>
                        </div>
                    `;
                }
            });
        }
        
        storiesBar.innerHTML = storiesHtml;
        
        // Add story click listeners
        document.querySelectorAll('.story-ring[data-user-id]').forEach(story => {
            story.addEventListener('click', () => {
                const stories = JSON.parse(story.dataset.stories);
                showStoryViewer(stories);
            });
        });
    } catch (error) {
        console.error('Load stories error:', error);
    }
}

// Render a single post
function renderPost(post) {
    return `
        <div class="post-card" data-post-id="${post.id}">
            <div class="post-header">
                <img class="post-avatar" src="${post.avatar_url || 'https://via.placeholder.com/40'}" alt="">
                <div class="post-username">${post.username}</div>
                <button class="post-menu">•••</button>
            </div>
            <img class="post-image" src="${post.image_url}" alt="">
            <div class="post-actions">
                <button class="like-btn" data-liked="${post.user_liked ? 'true' : 'false'}">
                    ${post.user_liked ? '❤️' : '🤍'} <span class="likes-count">${post.likes_count || 0}</span>
                </button>
                <button class="comment-btn">💬 <span class="comments-count">${post.comments_count || 0}</span></button>
                <button class="save-btn">${post.is_saved ? '🔖' : '🏷️'}</button>
                <button class="share-btn">📤</button>
            </div>
            <div class="post-caption">
                <strong>${post.username}</strong> ${post.caption || ''}
            </div>
            <div class="post-time">${new Date(post.created_at).toLocaleDateString()}</div>
            <button class="post-comments-link">View all ${post.comments_count || 0} comments</button>
        </div>
    `;
}

// Attach post event listeners
function attachPostEventListeners() {
    document.querySelectorAll('.like-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const postCard = btn.closest('.post-card');
            const postId = postCard.dataset.postId;
            const isLiked = btn.dataset.liked === 'true';
            
            try {
                const response = await fetch(`${API_URL}/likes`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${authToken}`
                    },
                    body: JSON.stringify({
                        post_id: postId,
                        action: isLiked ? 'unlike' : 'like'
                    })
                });
                
                const data = await response.json();
                if (data.success) {
                    const likesSpan = btn.querySelector('.likes-count');
                    const currentLikes = parseInt(likesSpan.textContent);
                    if (isLiked) {
                        likesSpan.textContent = currentLikes - 1;
                        btn.dataset.liked = 'false';
                        btn.innerHTML = `🤍 <span class="likes-count">${currentLikes - 1}</span>`;
                    } else {
                        likesSpan.textContent = currentLikes + 1;
                        btn.dataset.liked = 'true';
                        btn.innerHTML = `❤️ <span class="likes-count">${currentLikes + 1}</span>`;
                        if (data.points_earned) {
                            console.log(`Earned ${data.points_earned} points!`);
                        }
                    }
                }
            } catch (error) {
                console.error('Like error:', error);
            }
        });
    });
    
    document.querySelectorAll('.comment-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // TODO: Open comment modal
            alert('Comments feature coming soon!');
        });
    });
}

// Show story viewer
function showStoryViewer(stories) {
    // TODO: Implement story viewer
    alert('Story viewer coming soon!');
}

// Show create story modal
function showCreateStoryModal() {
    // TODO: Implement story creation
    alert('Create story coming soon!');
}

// Load explore page
async function loadExplorePage() {
    const pageContent = document.getElementById('page-content');
    const response = await fetch('explore.html');
    const html = await response.text();
    pageContent.innerHTML = html;
    
    await loadExploreContent();
    setupExploreSearch();
}

// Load explore content
async function loadExploreContent(category = 'for_you') {
    try {
        const response = await fetch(`${API_URL}/explore?category=${category}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        const exploreGrid = document.getElementById('explore-grid');
        if (exploreGrid && data.posts) {
            exploreGrid.innerHTML = data.posts.map(post => `
                <img src="${post.image_url}" alt="" data-post-id="${post.id}">
            `).join('');
        }
        
        const trendingContainer = document.getElementById('trending-hashtags');
        if (trendingContainer && data.trending_hashtags) {
            trendingContainer.innerHTML = data.trending_hashtags.map(tag => `
                <a href="#" data-hashtag="${tag.tag}">#${tag.tag}</a>
            `).join('');
        }
        
        const suggestedContainer = document.getElementById('suggested-users-list');
        if (suggestedContainer && data.suggested_users) {
            suggestedContainer.innerHTML = data.suggested_users.map(user => `
                <div class="suggested-user">
                    <img class="suggested-user-avatar" src="${user.avatar_url || 'https://via.placeholder.com/40'}" alt="">
                    <div class="suggested-user-info">
                        <div class="suggested-user-username">${user.username}</div>
                        <div class="suggested-user-followers">${user.followers_count || 0} followers</div>
                    </div>
                    <button class="suggested-user-follow" data-user="${user.username}">Follow</button>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Load explore error:', error);
    }
}

// Setup explore search
function setupExploreSearch() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const query = e.target.value;
                if (query.length >= 2) {
                    performSearch(query);
                }
            }, 500);
        });
    }
    
    document.querySelectorAll('.explore-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.explore-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            loadExploreContent(tab.dataset.category);
        });
    });
}

// Perform search
async function performSearch(query) {
    try {
        const response = await fetch(`${API_URL}/search?q=${encodeURIComponent(query)}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        // TODO: Display search results
        console.log('Search results:', data);
    } catch (error) {
        console.error('Search error:', error);
    }
}

// Load profile page
async function loadProfilePage(username) {
    const pageContent = document.getElementById('page-content');
    const response = await fetch('profile.html');
    const html = await response.text();
    pageContent.innerHTML = html;
    
    await loadProfile(username);
    setupProfileEvents();
}

// Load profile data
async function loadProfile(username) {
    try {
        const url = username ? `${API_URL}/profile?username=${username}` : `${API_URL}/profile`;
        const response = await fetch(url, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const profile = data.profile;
            const isOwnProfile = !username || profile.username === currentUser?.username;
            
            // Update profile UI
            document.getElementById('profile-avatar').src = profile.avatar_url || 'https://via.placeholder.com/90';
            document.getElementById('profile-username').textContent = profile.username;
            document.getElementById('profile-fullname').textContent = profile.full_name || '';
            document.getElementById('profile-bio').textContent = profile.bio || '';
            document.getElementById('posts-count').textContent = data.stats.posts_count;
            document.getElementById('followers-count').textContent = data.stats.followers_count;
            document.getElementById('following-count').textContent = data.stats.following_count;
            
            if (profile.website) {
                document.getElementById('profile-website').href = profile.website;
                document.getElementById('profile-website').textContent = profile.website;
            }
            
            if (profile.is_verified) {
                document.getElementById('verified-badge').style.display = 'inline-block';
            }
            
            if (profile.is_professional) {
                document.getElementById('professional-badge').style.display = 'inline-block';
            }
            
            // Show edit profile section for own profile
            if (isOwnProfile) {
                document.getElementById('edit-profile-section').style.display = 'block';
                document.getElementById('follow-btn').style.display = 'none';
            } else {
                document.getElementById('edit-profile-section').style.display = 'none';
                const followBtn = document.getElementById('follow-btn');
                followBtn.style.display = 'inline-block';
                followBtn.textContent = data.is_following ? 'Following' : 'Follow';
                followBtn.onclick = () => handleFollow(profile.username, !data.is_following);
            }
            
            // Render posts grid
            const postsGrid = document.getElementById('posts-grid');
            if (postsGrid && data.posts) {
                postsGrid.innerHTML = data.posts.map(post => `
                    <img src="${post.image_url}" alt="" data-post-id="${post.id}">
                `).join('');
            }
            
            // Update professional dashboard if available
            if (isOwnProfile && data.monetization) {
                updateProfessionalDashboard(data);
            }
        }
    } catch (error) {
        console.error('Load profile error:', error);
    }
}

// Handle follow action
async function handleFollow(username, shouldFollow) {
    try {
        const response = await fetch(`${API_URL}/follow`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                username: username,
                action: shouldFollow ? 'follow' : 'unfollow'
            })
        });
        
        const data = await response.json();
        if (data.success) {
            const followBtn = document.getElementById('follow-btn');
            followBtn.textContent = shouldFollow ? 'Following' : 'Follow';
            // Reload profile to update counts
            await loadProfile(username);
        }
    } catch (error) {
        console.error('Follow error:', error);
    }
}

// Setup profile events
function setupProfileEvents() {
    const editProfileBtn = document.getElementById('edit-profile-btn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', showEditProfileModal);
    }
    
    const dashboardBtn = document.getElementById('professional-dashboard-btn');
    if (dashboardBtn) {
        dashboardBtn.addEventListener('click', showProfessionalDashboard);
    }
    
    const changeAvatarBtn = document.getElementById('change-avatar-btn');
    if (changeAvatarBtn) {
        changeAvatarBtn.addEventListener('click', () => {
            // TODO: Implement avatar upload
            alert('Avatar upload coming soon!');
        });
    }
}

// Load notifications page
async function loadNotificationsPage() {
    const pageContent = document.getElementById('page-content');
    pageContent.innerHTML = '<div class="loading-spinner">Loading notifications...</div>';
    
    try {
        const response = await fetch(`${API_URL}/notifications`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success && data.notifications) {
            pageContent.innerHTML = `
                <div class="notifications-container">
                    <h2>Notifications</h2>
                    ${data.notifications.map(notif => `
                        <div class="notification-item">
                            <div class="notification-content">
                                <strong>${notif.from_username || 'System'}</strong>
                                <p>${notif.display_text}</p>
                                <small>${notif.time_ago}</small>
                            </div>
                        </div>
                    `).join('')}
                    ${data.notifications.length === 0 ? '<p>No notifications yet</p>' : ''}
                </div>
            `;
        }
    } catch (error) {
        console.error('Load notifications error:', error);
        pageContent.innerHTML = '<p>Error loading notifications</p>';
    }
}

// Load DMs page
async function loadDMsPage() {
    const pageContent = document.getElementById('page-content');
    const response = await fetch('dms.html');
    const html = await response.text();
    pageContent.innerHTML = html;
    
    await loadConversations();
    setupDMEvents();
}

// Load conversations
async function loadConversations() {
    try {
        const response = await fetch(`${API_URL}/dms`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        const conversationsList = document.getElementById('conversations-list');
        if (conversationsList && data.conversations) {
            conversationsList.innerHTML = data.conversations.map(conv => `
                <div class="conversation-item" data-conversation-id="${conv.id}">
                    <img class="conversation-avatar" src="${conv.other_user?.avatar_url || 'https://via.placeholder.com/50'}" alt="">
                    <div class="conversation-info">
                        <div class="conversation-username">${conv.other_user?.username || 'Group'}</div>
                        <div class="conversation-last-message">${conv.last_message || ''}</div>
                    </div>
                </div>
            `).join('');
            
            // Add click listeners
            document.querySelectorAll('.conversation-item').forEach(item => {
                item.addEventListener('click', () => loadConversation(item.dataset.conversationId));
            });
        }
    } catch (error) {
        console.error('Load conversations error:', error);
    }
}

// Setup DM events
function setupDMEvents() {
    const newChatBtn = document.getElementById('new-chat-btn');
    if (newChatBtn) {
        newChatBtn.addEventListener('click', () => {
            alert('New chat coming soon!');
        });
    }
}

// Load conversation messages
async function loadConversation(conversationId) {
    currentConversationId = conversationId;
    
    try {
        const response = await fetch(`${API_URL}/dms?conversation_id=${conversationId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        document.getElementById('chat-placeholder').style.display = 'none';
        document.getElementById('chat-active').style.display = 'flex';
        
        const messagesContainer = document.getElementById('chat-messages');
        if (messagesContainer && data.messages) {
            messagesContainer.innerHTML = data.messages.map(msg => `
                <div class="message ${msg.sender_id === currentUser?.id ? 'message-sent' : 'message-received'}">
                    ${msg.message_type === 'text' ? msg.content : 
                      msg.message_type === 'image' ? `<img src="${msg.image_url}" style="max-width: 200px;">` : 
                      msg.message_type === 'voice' ? `<audio controls src="${msg.voice_url}"></audio>` : msg.content}
                    <small>${new Date(msg.created_at).toLocaleTimeString()}</small>
                </div>
            `).join('');
            
            // Scroll to bottom
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        
        // Setup send message
        const sendBtn = document.getElementById('chat-send-btn');
        const messageInput = document.getElementById('chat-message-input');
        
        const sendMessage = async () => {
            const content = messageInput.value.trim();
            if (!content) return;
            
            try {
                const response = await fetch(`${API_URL}/dms`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${authToken}`
                    },
                    body: JSON.stringify({
                        action: 'message',
                        conversation_id: conversationId,
                        content: content,
                        message_type: 'text'
                    })
                });
                
                if (response.ok) {
                    messageInput.value = '';
                    await loadConversation(conversationId);
                }
            } catch (error) {
                console.error('Send message error:', error);
            }
        };
        
        sendBtn.onclick = sendMessage;
        messageInput.onkeypress = (e) => {
            if (e.key === 'Enter') sendMessage();
        };
    } catch (error) {
        console.error('Load conversation error:', error);
    }
}

// Update professional dashboard
function updateProfessionalDashboard(data) {
    const monetization = data.monetization;
    if (monetization) {
        const monetizationInfo = document.getElementById('monetization-info');
        if (monetizationInfo) {
            monetizationInfo.innerHTML = `
                <p>Status: ${monetization.is_monetization_unlocked ? '✅ Unlocked' : '🔒 Locked'}</p>
                <p>Total Points: ${monetization.total_points || 0}</p>
                <p>Total Earnings: KES ${(monetization.total_earnings_kes || 0).toFixed(2)}</p>
                ${!monetization.is_monetization_unlocked ? `
                    <p>Requirements: 100k followers, 100k views, verified badge</p>
                ` : ''}
            `;
        }
        
        const earningsStats = document.getElementById('earnings-stats');
        if (earningsStats && data.stats) {
            earningsStats.innerHTML = `
                <p>Followers: ${data.stats.followers_count}</p>
                <p>Posts: ${data.stats.posts_count}</p>
                <p>Profile Views: ${data.stats.total_views || 0}</p>
            `;
        }
    }
    
    const verificationStatus = document.getElementById('verification-status');
    if (verificationStatus && data.profile) {
        if (data.profile.is_verified) {
            verificationStatus.innerHTML = '<p>✅ Your account is verified</p>';
        } else {
            verificationStatus.innerHTML = '<p>Apply for verification to get the blue checkmark badge.</p>';
        }
    }
}

// Show edit profile modal
function showEditProfileModal() {
    // TODO: Implement edit profile modal
    alert('Edit profile coming soon!');
}

// Show professional dashboard
function showProfessionalDashboard() {
    // TODO: Implement professional dashboard
    alert('Professional dashboard coming soon!');
}

// Handle create post
async function handleCreatePost() {
    const caption = document.getElementById('post-caption').value;
    const imageFile = document.getElementById('post-image').files[0];
    
    if (!imageFile) {
        alert('Please select an image');
        return;
    }
    
    const formData = new FormData();
    formData.append('caption', caption);
    formData.append('image', imageFile);
    
    try {
        const response = await fetch(`${API_URL}/posts`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` },
            body: formData
        });
        
        const data = await response.json();
        if (data.success) {
            alert('Post created successfully!');
            document.getElementById('post-caption').value = '';
            document.getElementById('post-image').value = '';
            document.querySelector('.modal').style.display = 'none';
            await loadFeed();
        } else {
            alert(data.error || 'Failed to create post');
        }
    } catch (error) {
        console.error('Create post error:', error);
        alert('Error creating post');
    }
}