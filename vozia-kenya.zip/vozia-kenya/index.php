<?php
require_once 'config.php';

$request_method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];

// Remove query string if present
$request_uri = strtok($request_uri, '?');

// Remove /api prefix and clean path
$path = str_replace('/api', '', $request_uri);
$path = trim($path, '/');

// API Router - All endpoints
switch ($path) {
    // Health check
    case '':
    case 'health':
        json_response(["status" => "ok", "message" => "Vozia Kenya API is running", "timestamp" => date('c')]);
        break;
    
    // Authentication
    case 'auth/register':
        require_once 'api/auth/register.php';
        break;
        
    case 'auth/login':
        require_once 'api/auth/login.php';
        break;
        
    case 'auth/verify':
        require_once 'api/auth/verify.php';
        break;
    
    case 'auth/logout':
        require_once 'api/auth/logout.php';
        break;
    
    // Posts
    case 'posts':
        if ($request_method === 'GET') {
            require_once 'api/posts.php';
        } elseif ($request_method === 'POST') {
            require_once 'api/posts.php';
        }
        break;
    
    case 'posts/single':
        require_once 'api/posts.php';
        break;
    
    // Interactions
    case 'likes':
        require_once 'api/likes.php';
        break;
        
    case 'comments':
        require_once 'api/comments.php';
        break;
    
    case 'comments/like':
        require_once 'api/comments.php';
        break;
    
    // User actions
    case 'profile':
        require_once 'api/profile.php';
        break;
        
    case 'follow':
        require_once 'api/follow.php';
        break;
    
    case 'followers':
        require_once 'api/follow.php';
        break;
    
    case 'following':
        require_once 'api/follow.php';
        break;
    
    // Feed & Discovery
    case 'feed':
        require_once 'api/feed.php';
        break;
        
    case 'explore':
        require_once 'api/explore.php';
        break;
        
    case 'search':
        require_once 'api/search.php';
        break;
    
    case 'hashtags':
        require_once 'api/search.php';
        break;
    
    // Direct Messages
    case 'dms':
    case 'dms/conversations':
    case 'dms/messages':
        require_once 'api/dms.php';
        break;
    
    // Stories
    case 'stories':
    case 'stories/view':
    case 'stories/reply':
        require_once 'api/stories.php';
        break;
    
    case 'highlights':
        require_once 'api/stories.php';
        break;
    
    // Guides & Notes
    case 'guides':
        require_once 'api/guides.php';
        break;
    
    case 'notes':
        require_once 'api/notes.php';
        break;
    
    // Notifications
    case 'notifications':
        require_once 'api/notifications.php';
        break;
    
    // Earnings System
    case 'earnings':
        require_once 'api/earnings.php';
        break;
    
    case 'earnings/stats':
        require_once 'api/earnings.php';
        break;
    
    // Withdrawals (Admin panel)
    case 'withdraw':
        require_once 'api/withdraw.php';
        break;
    
    case 'withdraw/history':
        require_once 'api/withdraw.php';
        break;
    
    // Verification Badge Request
    case 'verify-request':
        require_once 'api/verify-request.php';
        break;
    
    case 'verify-status':
        require_once 'api/verify-request.php';
        break;
    
    // Deep Contact (Support)
    case 'contact':
        require_once 'api/contact.php';
        break;
    
    // Settings
    case 'settings':
        require_once 'api/settings.php';
        break;
    
    case 'settings/privacy':
        require_once 'api/settings.php';
        break;
    
    // Block/Mute/Restrict
    case 'block':
        require_once 'api/block.php';
        break;
    
    case 'mute':
        require_once 'api/block.php';
        break;
    
    case 'restrict':
        require_once 'api/block.php';
        break;
    
    // Report content
    case 'report':
        require_once 'api/report.php';
        break;
    
    // Default 404
    default:
        json_response(["error" => "Endpoint not found", "path" => $path], 404);
        break;
}
?>