<?php
// ============================================
// VOZIA KENYA - COMPLETE CONFIGURATION
// ============================================

// Error reporting (turn off in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ============================================
// DATABASE CONNECTION (Render PostgreSQL)
// ============================================
$database_url = getenv('DATABASE_URL');

if (!$database_url) {
    // Render PostgreSQL external URL
    $database_url = "postgresql://vozia_admin:xRREQu93roCVSnjSEM7fpe11vzIRDexn@dpg-d7ge20hf9bms73ast2tg-a.ohio-postgres.render.com:5432/vozia_kenya?sslmode=require";
}

// Parse the database URL
$db = parse_url($database_url);

$host = $db['host'];
$port = $db['port'] ?? 5432;
$user = $db['user'];
$pass = $db['pass'];
$dbname = ltrim($db['path'], '/');

// Add SSL requirement for Render
$dsn = "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require";

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die(json_encode(["error" => "Database connection failed: " . $e->getMessage()]));
}

// ============================================
// CLOUDINARY CONFIGURATION (Image Storage)
// ============================================
define('CLOUDINARY_CLOUD_NAME', 'dvelzjywv');
define('CLOUDINARY_API_KEY', '551987172277626');
define('CLOUDINARY_API_SECRET', 'kRm9SFbr_P5iVkj5qZvhtCyUI64');
define('CLOUDINARY_URL', 'cloudinary://551987172277626:kRm9SFbr_P5iVkj5qZvhtCyUI64@dvelzjywv');

// Function to upload image to Cloudinary
function upload_to_cloudinary($image_data, $folder = 'vozia_kenya') {
    $cloud_name = CLOUDINARY_CLOUD_NAME;
    $api_key = CLOUDINARY_API_KEY;
    $api_secret = CLOUDINARY_API_SECRET;
    
    $timestamp = time();
    $signature = sha1("folder=$folder&timestamp=$timestamp" . $api_secret);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.cloudinary.com/v1_1/$cloud_name/image/upload");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    if (file_exists($image_data)) {
        $file_data = curl_file_create($image_data);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'file' => $file_data,
            'api_key' => $api_key,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'folder' => $folder
        ]);
    } else {
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'file' => $image_data,
            'api_key' => $api_key,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'folder' => $folder
        ]);
    }
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    return $result['secure_url'] ?? null;
}

// ============================================
// RESEND EMAIL CONFIGURATION (WORKING)
// ============================================
define('RESEND_API_KEY', 're_jPPWcBhc_4DE2PFH3ohtaszcA1c5qZy2K');
define('RESEND_FROM_EMAIL', 'noreply@markcousa.shop');
define('RESEND_FROM_NAME', 'Vozia Kenya');

// Function to send email via Resend
function send_email($to, $subject, $html_content) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.resend.com/emails");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . RESEND_API_KEY,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'from' => RESEND_FROM_NAME . ' <' . RESEND_FROM_EMAIL . '>',
        'to' => $to,
        'subject' => $subject,
        'html' => $html_content
    ]));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

// ============================================
// ADMIN PANEL CONFIGURATION
// ============================================
define('ADMIN_PANEL_URL', 'https://chic-lily-42ff8e.netlify.app/api');

// Function to send request to admin panel
function send_to_admin_panel($endpoint, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, ADMIN_PANEL_URL . '/' . $endpoint);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ['success' => $http_code === 200, 'response' => $response];
}

// ============================================
// SESSION & CORS
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function verify_token($pdo, $token) {
    $stmt = $pdo->prepare("SELECT user_id FROM user_sessions WHERE session_token = ? AND expires_at > NOW()");
    $stmt->execute([$token]);
    return $stmt->fetchColumn();
}

function get_user_id($pdo) {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? '';
    
    if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
        $token = $matches[1];
        return verify_token($pdo, $token);
    }
    return null;
}

function json_response($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit();
}

function get_user_by_id($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT id, username, email, full_name, avatar_url, bio, is_verified FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function generate_token($length = 32) {
    return bin2hex(random_bytes($length));
}

// ============================================
// CONFIGURATION COMPLETE - ALL SYSTEMS GO
// ============================================
?>