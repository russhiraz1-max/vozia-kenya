<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Get earnings data
if ($request_method === 'GET') {
    $type = $_GET['type'] ?? 'stats'; // 'stats', 'history', 'withdrawals'
    $limit = min(100, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Get monetization status
    $stmt = $pdo->prepare("
        SELECT * FROM user_monetization WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $monetization = $stmt->fetch();
    
    // Get user data for requirements check
    $stmt = $pdo->prepare("
        SELECT u.is_verified,
               (SELECT COUNT(*) FROM followers WHERE following_id = u.id AND is_approved = true) as followers_count,
               (SELECT COALESCE(SUM(profile_views), 0) FROM daily_metrics WHERE user_id = u.id) as total_views
        FROM users u
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_stats = $stmt->fetch();
    
    $requirements_met = [
        'followers_100k' => $user_stats['followers_count'] >= 100000,
        'views_100k' => $user_stats['total_views'] >= 100000,
        'verified' => (bool)$user_stats['is_verified'],
        'all_met' => ($user_stats['followers_count'] >= 100000 && 
                      $user_stats['total_views'] >= 100000 && 
                      $user_stats['is_verified'])
    ];
    
    // Check if monetization is unlocked
    $is_unlocked = $monetization && $monetization['is_monetization_unlocked'];
    
    if ($type === 'stats') {
        // Get earnings history summary
        $stmt = $pdo->prepare("
            SELECT 
                COALESCE(SUM(points_earned), 0) as total_points,
                COALESCE(SUM(kes_value), 0) as total_kes,
                COUNT(*) as total_likes_earned,
                DATE(created_at) as date
            FROM like_earnings
            WHERE user_id = ?
            GROUP BY DATE(created_at)
            ORDER BY DATE(created_at) DESC
            LIMIT 30
        ");
        $stmt->execute([$user_id]);
        $daily_earnings = $stmt->fetchAll();
        
        // Get total stats
        $stmt = $pdo->prepare("
            SELECT 
                COALESCE(SUM(points_earned), 0) as total_points,
                COALESCE(SUM(kes_value), 0) as total_kes,
                COUNT(*) as total_likes_earned
            FROM like_earnings
            WHERE user_id = ?
        ");
        $stmt->execute([$user_id]);
        $totals = $stmt->fetch();
        
        // Get pending withdrawal amount
        $stmt = $pdo->prepare("
            SELECT COALESCE(SUM(amount_kes), 0) as pending_amount
            FROM withdrawal_requests
            WHERE user_id = ? AND status = 'pending'
        ");
        $stmt->execute([$user_id]);
        $pending = $stmt->fetch();
        
        // Calculate available balance (total_kes - pending_withdrawals - completed_withdrawals)
        $stmt = $pdo->prepare("
            SELECT COALESCE(SUM(amount_kes), 0) as completed_amount
            FROM withdrawal_requests
            WHERE user_id = ? AND status = 'approved'
        ");
        $stmt->execute([$user_id]);
        $completed = $stmt->fetch();
        
        $available_kes = ($totals['total_kes'] - $pending['pending_amount'] - $completed['completed_amount']);
        
        json_response([
            "success" => true,
            "is_monetization_unlocked" => $is_unlocked,
            "unlocked_at" => $monetization['unlocked_at'] ?? null,
            "requirements" => $requirements_met,
            "stats" => [
                "total_points" => (int)($totals['total_points'] ?? 0),
                "total_kes" => (float)($totals['total_kes'] ?? 0),
                "total_likes_earned" => (int)($totals['total_likes_earned'] ?? 0),
                "available_kes" => max(0, (float)$available_kes),
                "pending_withdrawals" => (float)$pending['pending_amount'],
                "completed_withdrawals" => (float)$completed['completed_amount']
            ],
            "daily_earnings" => $daily_earnings,
            "minimum_withdrawal" => 500, // KES
            "points_per_like" => 5,
            "kes_per_point" => 0.002, // 5 points = 0.010 KES, so per point = 0.002
            "kes_per_like" => 0.010
        ]);
    }
    
    elseif ($type === 'history') {
        // Get like earnings history
        $stmt = $pdo->prepare("
            SELECT le.*, 
                   u.username as liker_username, 
                   u.full_name as liker_full_name,
                   u.avatar_url as liker_avatar,
                   p.image_url as post_image,
                   p.caption as post_caption
            FROM like_earnings le
            JOIN users u ON le.liker_id = u.id
            JOIN posts p ON le.post_id = p.id
            WHERE le.user_id = ?
            ORDER BY le.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $limit, $offset]);
        $history = $stmt->fetchAll();
        
        // Get total count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM like_earnings WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "history" => $history,
            "total" => (int)$total,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    
    elseif ($type === 'withdrawals') {
        // Get withdrawal requests history
        $stmt = $pdo->prepare("
            SELECT * FROM withdrawal_requests
            WHERE user_id = ?
            ORDER BY requested_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $limit, $offset]);
        $withdrawals = $stmt->fetchAll();
        
        // Get total count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM withdrawal_requests WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "withdrawals" => $withdrawals,
            "total" => (int)$total,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    
    else {
        json_response(["error" => "Invalid type. Use 'stats', 'history', or 'withdrawals'"], 400);
    }
}

// POST - Request withdrawal
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $amount_kes = (float)($input['amount_kes'] ?? 0);
    $payment_method = $input['payment_method'] ?? null; // 'mpesa', 'bank', 'paypal'
    $payment_details = $input['payment_details'] ?? null;
    
    // Validate
    if ($amount_kes < 500) {
        json_response(["error" => "Minimum withdrawal amount is 500 KES"], 400);
    }
    
    if (!$payment_method || !$payment_details) {
        json_response(["error" => "Payment method and details are required"], 400);
    }
    
    // Check if monetization is unlocked
    $stmt = $pdo->prepare("
        SELECT is_monetization_unlocked, total_points, total_earnings_kes 
        FROM user_monetization WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $monetization = $stmt->fetch();
    
    if (!$monetization || !$monetization['is_monetization_unlocked']) {
        json_response(["error" => "Monetization not unlocked. You need 100k followers, 100k views, and verified badge."], 403);
    }
    
    // Check if enough balance
    // Calculate total earned
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(kes_value), 0) as total_kes FROM like_earnings WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_kes = $stmt->fetchColumn();
    
    // Calculate pending withdrawals
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount_kes), 0) as pending FROM withdrawal_requests WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$user_id]);
    $pending = $stmt->fetchColumn();
    
    // Calculate completed withdrawals
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount_kes), 0) as completed FROM withdrawal_requests WHERE user_id = ? AND status = 'approved'");
    $stmt->execute([$user_id]);
    $completed = $stmt->fetchColumn();
    
    $available = $total_kes - $pending - $completed;
    
    if ($amount_kes > $available) {
        json_response(["error" => "Insufficient balance. Available: {$available} KES"], 400);
    }
    
    // Calculate points to deduct (500 KES = 250,000 points because 0.010 KES = 5 points, so 1 KES = 500 points)
    $points_to_deduct = $amount_kes * 500;
    
    // Get user details for admin panel
    $stmt = $pdo->prepare("SELECT username, email, phone_number, full_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Create withdrawal request
    $stmt = $pdo->prepare("
        INSERT INTO withdrawal_requests (
            user_id, amount_kes, points_deducted, payment_method, payment_details,
            full_name, email, phone_number, reason, status, requested_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
        RETURNING id
    ");
    $stmt->execute([
        $user_id, $amount_kes, $points_to_deduct, $payment_method, $payment_details,
        $user['full_name'] ?? $user['username'], $user['email'], $user['phone_number'] ?? '',
        "Withdrawal request for {$amount_kes} KES via {$payment_method}"
    ]);
    $withdrawal_id = $stmt->fetchColumn();
    
    // TODO: Send request to admin panel at https://chic-lily-42ff8e.netlify.app/
    // This would be a cURL request to the admin panel API
    
    json_response([
        "success" => true,
        "message" => "Withdrawal request submitted. Waiting for admin approval.",
        "withdrawal_id" => $withdrawal_id,
        "amount_kes" => $amount_kes,
        "points_deducted" => $points_to_deduct,
        "status" => "pending"
    ], 201);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>