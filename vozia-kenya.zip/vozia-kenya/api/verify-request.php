<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Check verification status or get request history
if ($request_method === 'GET') {
    $request_id = $_GET['id'] ?? null;
    
    // Get user's current verification status
    $stmt = $pdo->prepare("SELECT is_verified, username, email, full_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Check if already verified
    if ($user['is_verified']) {
        json_response([
            "success" => true,
            "is_verified" => true,
            "message" => "Your account is already verified",
            "badge_type" => "verified"
        ]);
    }
    
    // Get pending verification request
    $stmt = $pdo->prepare("
        SELECT * FROM verification_requests 
        WHERE user_id = ? AND status = 'pending'
        ORDER BY requested_at DESC LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $pending_request = $stmt->fetch();
    
    // Get rejected request (if any)
    $stmt = $pdo->prepare("
        SELECT * FROM verification_requests 
        WHERE user_id = ? AND status = 'rejected'
        ORDER BY requested_at DESC LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $rejected_request = $stmt->fetch();
    
    // Check if user meets requirements for verification
    // Requirements: 100k followers, 100k views (same as monetization)
    $stmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM followers WHERE following_id = ? AND is_approved = true) as followers_count,
            (SELECT COALESCE(SUM(profile_views), 0) FROM daily_metrics WHERE user_id = ?) as total_views
    ");
    $stmt->execute([$user_id, $user_id]);
    $stats = $stmt->fetch();
    
    $requirements = [
        'followers_100k' => $stats['followers_count'] >= 100000,
        'views_100k' => $stats['total_views'] >= 100000,
        'has_pending_request' => !empty($pending_request),
        'has_rejected_request' => !empty($rejected_request)
    ];
    $requirements['all_met'] = $requirements['followers_100k'] && $requirements['views_100k'];
    
    json_response([
        "success" => true,
        "is_verified" => false,
        "verification_status" => $pending_request ? 'pending' : ($rejected_request ? 'rejected' : 'not_applied'),
        "requirements" => $requirements,
        "pending_request" => $pending_request,
        "rejected_request" => $rejected_request,
        "stats" => [
            "followers_count" => (int)$stats['followers_count'],
            "total_views" => (int)$stats['total_views']
        ]
    ]);
}

// POST - Submit verification request
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // REQUIRED CONTACT INFO (all mandatory)
    $full_name = trim($input['full_name'] ?? '');
    $email = trim($input['email'] ?? '');
    $phone_number = trim($input['phone_number'] ?? '');
    $reason = trim($input['reason'] ?? '');
    $supporting_docs = $input['supporting_docs'] ?? null;
    $additional_notes = trim($input['additional_notes'] ?? '');
    
    // Validate required fields
    if (empty($full_name)) {
        json_response(["error" => "Full name is required"], 400);
    }
    
    if (empty($email)) {
        json_response(["error" => "Email is required"], 400);
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_response(["error" => "Valid email is required"], 400);
    }
    
    if (empty($phone_number)) {
        json_response(["error" => "Phone number is required"], 400);
    }
    
    if (empty($reason)) {
        json_response(["error" => "Reason for verification is required"], 400);
    }
    
    // Check if user is already verified
    $stmt = $pdo->prepare("SELECT is_verified FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if ($user['is_verified']) {
        json_response(["error" => "Your account is already verified"], 400);
    }
    
    // Check if there's already a pending request
    $stmt = $pdo->prepare("
        SELECT id FROM verification_requests 
        WHERE user_id = ? AND status = 'pending'
    ");
    $stmt->execute([$user_id]);
    if ($stmt->fetch()) {
        json_response(["error" => "You already have a pending verification request"], 400);
    }
    
    // Check if user meets minimum requirements
    $stmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM followers WHERE following_id = ? AND is_approved = true) as followers_count,
            (SELECT COALESCE(SUM(profile_views), 0) FROM daily_metrics WHERE user_id = ?) as total_views
    ");
    $stmt->execute([$user_id, $user_id]);
    $stats = $stmt->fetch();
    
    if ($stats['followers_count'] < 100000 || $stats['total_views'] < 100000) {
        json_response([
            "error" => "You need at least 100,000 followers and 100,000 profile views to request verification",
            "followers" => (int)$stats['followers_count'],
            "views" => (int)$stats['total_views'],
            "required_followers" => 100000,
            "required_views" => 100000
        ], 403);
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    // Create verification request
    $stmt = $pdo->prepare("
        INSERT INTO verification_requests (
            user_id, full_name, email, phone_number, reason, supporting_docs, 
            additional_notes, status, requested_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
        RETURNING id
    ");
    $stmt->execute([
        $user_id, $full_name, $email, $phone_number, $reason, 
        $supporting_docs, $additional_notes
    ]);
    $request_id = $stmt->fetchColumn();
    
    // TODO: Send request to admin panel at https://chic-lily-42ff8e.netlify.app/
    // This would be a cURL POST request to the admin panel API
    
    // Create notification for user
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, type, from_user_id, content, created_at)
        VALUES (?, 'system', ?, 'Your verification request has been submitted. You will be notified when it is reviewed.', NOW())
    ");
    $stmt->execute([$user_id, $user_id]);
    
    json_response([
        "success" => true,
        "message" => "Verification request submitted successfully. The admin will review your application.",
        "request_id" => $request_id,
        "status" => "pending"
    ], 201);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>