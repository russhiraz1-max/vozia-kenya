<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Fetch stories
if ($request_method === 'GET') {
    $story_id = $_GET['story_id'] ?? null;
    $username = $_GET['username'] ?? null;
    $highlight_id = $_GET['highlight_id'] ?? null;
    
    // Get single story by ID
    if ($story_id) {
        $stmt = $pdo->prepare("
            SELECT s.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM story_views WHERE story_id = s.id) as views_count,
                   (SELECT COUNT(*) FROM story_views WHERE story_id = s.id AND viewer_id = ?) as user_viewed
            FROM stories s
            JOIN users u ON s.user_id = u.id
            WHERE s.id = ? AND s.expires_at > NOW()
        ");
        $stmt->execute([$user_id, $story_id]);
        $story = $stmt->fetch();
        
        if (!$story) {
            json_response(["error" => "Story not found or expired"], 404);
        }
        
        // Record view
        $stmt = $pdo->prepare("
            INSERT INTO story_views (story_id, viewer_id, viewed_at) 
            VALUES (?, ?, NOW())
            ON CONFLICT (story_id, viewer_id) DO NOTHING
        ");
        $stmt->execute([$story_id, $user_id]);
        
        json_response(["success" => true, "story" => $story]);
    }
    
    // Get stories by username (for profile)
    if ($username) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $target_user = $stmt->fetch();
        
        if (!$target_user) {
            json_response(["error" => "User not found"], 404);
        }
        
        $stmt = $pdo->prepare("
            SELECT s.*, 
                   (SELECT COUNT(*) FROM story_views WHERE story_id = s.id) as views_count,
                   (SELECT COUNT(*) FROM story_views WHERE story_id = s.id AND viewer_id = ?) as user_viewed
            FROM stories s
            WHERE s.user_id = ? AND s.expires_at > NOW()
            ORDER BY s.created_at DESC
        ");
        $stmt->execute([$user_id, $target_user['id']]);
        $stories = $stmt->fetchAll();
        
        json_response(["success" => true, "stories" => $stories]);
    }
    
    // Get highlight by ID
    if ($highlight_id) {
        $stmt = $pdo->prepare("
            SELECT h.*, 
                   (SELECT image_url FROM highlight_stories hs JOIN stories s ON hs.story_id = s.id WHERE hs.highlight_id = h.id LIMIT 1) as cover_image
            FROM highlights h
            WHERE h.id = ?
        ");
        $stmt->execute([$highlight_id]);
        $highlight = $stmt->fetch();
        
        if (!$highlight) {
            json_response(["error" => "Highlight not found"], 404);
        }
        
        // Get stories in highlight
        $stmt = $pdo->prepare("
            SELECT s.* FROM stories s
            JOIN highlight_stories hs ON s.id = hs.story_id
            WHERE hs.highlight_id = ?
            ORDER BY hs.added_at ASC
        ");
        $stmt->execute([$highlight_id]);
        $stories = $stmt->fetchAll();
        
        $highlight['stories'] = $stories;
        
        json_response(["success" => true, "highlight" => $highlight]);
    }
    
    // Get all active stories from followed users (story feed)
    $stmt = $pdo->prepare("
        SELECT DISTINCT s.*, u.username, u.full_name, u.avatar_url, u.is_verified,
               (SELECT COUNT(*) FROM story_views WHERE story_id = s.id) as views_count,
               (SELECT COUNT(*) FROM story_views WHERE story_id = s.id AND viewer_id = ?) as user_viewed
        FROM stories s
        JOIN users u ON s.user_id = u.id
        WHERE s.expires_at > NOW()
        AND (
            s.user_id IN (SELECT following_id FROM followers WHERE follower_id = ? AND is_approved = true)
            OR s.user_id = ?
        )
        AND (s.is_close_friends_only = false OR s.user_id IN (
            SELECT following_id FROM followers WHERE follower_id = ? AND is_approved = true
        ))
        ORDER BY s.user_id, s.created_at DESC
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    $all_stories = $stmt->fetchAll();
    
    // Group by user
    $stories_by_user = [];
    foreach ($all_stories as $story) {
        $uid = $story['user_id'];
        if (!isset($stories_by_user[$uid])) {
            $stories_by_user[$uid] = [
                'user_id' => $story['user_id'],
                'username' => $story['username'],
                'full_name' => $story['full_name'],
                'avatar_url' => $story['avatar_url'],
                'is_verified' => $story['is_verified'],
                'stories' => []
            ];
        }
        $stories_by_user[$uid]['stories'][] = $story;
    }
    
    json_response([
        "success" => true,
        "stories_feed" => array_values($stories_by_user)
    ]);
}

// POST - Create story, add to highlight, or reply
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'create'; // 'create', 'highlight', 'reply'
    
    // Create new story (PHOTO ONLY - no videos)
    if ($action === 'create') {
        $caption = $input['caption'] ?? '';
        $is_close_friends_only = $input['is_close_friends_only'] ?? false;
        
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            json_response(["error" => "Image is required for story"], 400);
        }
        
        $image = $_FILES['image'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
        
        if (!in_array($image['type'], $allowed_types)) {
            json_response(["error" => "Only JPG, PNG, and WEBP images are allowed"], 400);
        }
        
        // TODO: Upload to Cloudinary
        $image_data = base64_encode(file_get_contents($image['tmp_name']));
        $image_url = "data:" . $image['type'] . ";base64," . $image_data;
        
        $stmt = $pdo->prepare("
            INSERT INTO stories (user_id, image_url, caption, is_close_friends_only, expires_at, created_at) 
            VALUES (?, ?, ?, ?, NOW() + INTERVAL '24 hours', NOW())
            RETURNING id
        ");
        $stmt->execute([$user_id, $image_url, $caption, $is_close_friends_only]);
        $story_id = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "message" => "Story posted successfully",
            "story_id" => $story_id,
            "image_url" => $image_url,
            "expires_at" => date('Y-m-d H:i:s', strtotime('+24 hours'))
        ], 201);
    }
    
    // Add story to highlight
    if ($action === 'highlight') {
        $story_id = $input['story_id'] ?? null;
        $highlight_name = $input['highlight_name'] ?? null;
        $highlight_id = $input['highlight_id'] ?? null;
        
        if (!$story_id) {
            json_response(["error" => "Story ID is required"], 400);
        }
        
        // Check if story belongs to user
        $stmt = $pdo->prepare("SELECT id FROM stories WHERE id = ? AND user_id = ?");
        $stmt->execute([$story_id, $user_id]);
        if (!$stmt->fetch()) {
            json_response(["error" => "Story not found or doesn't belong to you"], 404);
        }
        
        // Create new highlight if name provided
        if ($highlight_name && !$highlight_id) {
            $stmt = $pdo->prepare("
                INSERT INTO highlights (user_id, name, created_at) 
                VALUES (?, ?, NOW())
                RETURNING id
            ");
            $stmt->execute([$user_id, $highlight_name]);
            $highlight_id = $stmt->fetchColumn();
        }
        
        if (!$highlight_id) {
            json_response(["error" => "Highlight ID or name is required"], 400);
        }
        
        // Check if highlight belongs to user
        $stmt = $pdo->prepare("SELECT id FROM highlights WHERE id = ? AND user_id = ?");
        $stmt->execute([$highlight_id, $user_id]);
        if (!$stmt->fetch()) {
            json_response(["error" => "Highlight not found or doesn't belong to you"], 404);
        }
        
        // Add story to highlight
        $stmt = $pdo->prepare("
            INSERT INTO highlight_stories (highlight_id, story_id, added_at) 
            VALUES (?, ?, NOW())
            ON CONFLICT DO NOTHING
        ");
        $stmt->execute([$highlight_id, $story_id]);
        
        json_response(["success" => true, "message" => "Story added to highlight"]);
    }
    
    // Reply to a story
    if ($action === 'reply') {
        $story_id = $input['story_id'] ?? null;
        $message = $input['message'] ?? '';
        
        if (!$story_id || empty($message)) {
            json_response(["error" => "Story ID and message are required"], 400);
        }
        
        // Get story owner
        $stmt = $pdo->prepare("SELECT user_id FROM stories WHERE id = ?");
        $stmt->execute([$story_id]);
        $story = $stmt->fetch();
        
        if (!$story) {
            json_response(["error" => "Story not found"], 404);
        }
        
        // Save reply
        $stmt = $pdo->prepare("
            INSERT INTO story_replies (story_id, user_id, message, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$story_id, $user_id, $message]);
        
        // Create notification
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, from_user_id, story_id, content, created_at)
            VALUES (?, 'story_reply', ?, ?, ?, NOW())
        ");
        $stmt->execute([$story['user_id'], $user_id, $story_id, "replied to your story"]);
        
        json_response(["success" => true, "message" => "Reply sent"]);
    }
    
    json_response(["error" => "Invalid action"], 400);
}

// DELETE - Delete story or highlight
if ($request_method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $story_id = $input['story_id'] ?? null;
    $highlight_id = $input['highlight_id'] ?? null;
    
    if ($story_id) {
        $stmt = $pdo->prepare("SELECT user_id FROM stories WHERE id = ?");
        $stmt->execute([$story_id]);
        $story = $stmt->fetch();
        
        if (!$story) {
            json_response(["error" => "Story not found"], 404);
        }
        
        if ($story['user_id'] != $user_id) {
            json_response(["error" => "You can only delete your own stories"], 403);
        }
        
        $stmt = $pdo->prepare("DELETE FROM stories WHERE id = ?");
        $stmt->execute([$story_id]);
        
        json_response(["success" => true, "message" => "Story deleted"]);
    }
    
    if ($highlight_id) {
        $stmt = $pdo->prepare("SELECT user_id FROM highlights WHERE id = ?");
        $stmt->execute([$highlight_id]);
        $highlight = $stmt->fetch();
        
        if (!$highlight) {
            json_response(["error" => "Highlight not found"], 404);
        }
        
        if ($highlight['user_id'] != $user_id) {
            json_response(["error" => "You can only delete your own highlights"], 403);
        }
        
        $stmt = $pdo->prepare("DELETE FROM highlights WHERE id = ?");
        $stmt->execute([$highlight_id]);
        
        json_response(["success" => true, "message" => "Highlight deleted"]);
    }
    
    json_response(["error" => "Story ID or Highlight ID required"], 400);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>