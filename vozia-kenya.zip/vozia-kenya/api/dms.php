<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Get conversations or messages
if ($request_method === 'GET') {
    $conversation_id = $_GET['conversation_id'] ?? null;
    $limit = min(100, (int)($_GET['limit'] ?? 50));
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Get all conversations for the user
    if (!$conversation_id) {
        $stmt = $pdo->prepare("
            SELECT c.*,
                   (SELECT json_build_object('id', u.id, 'username', u.username, 'full_name', u.full_name, 'avatar_url', u.avatar_url)
                    FROM users u
                    WHERE u.id IN (
                        SELECT cp.user_id FROM conversation_participants cp 
                        WHERE cp.conversation_id = c.id AND cp.user_id != ?
                        LIMIT 1
                    )) as other_user,
                   (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND is_read = false AND sender_id != ?) as unread_count,
                   (SELECT content FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message,
                   (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message_time
            FROM conversations c
            JOIN conversation_participants cp ON c.id = cp.conversation_id
            WHERE cp.user_id = ?
            ORDER BY last_message_time DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $limit, $offset]);
        $conversations = $stmt->fetchAll();
        
        json_response([
            "success" => true,
            "conversations" => $conversations,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    
    // Get messages in a conversation
    if ($conversation_id) {
        // Check if user is in the conversation
        $stmt = $pdo->prepare("
            SELECT id FROM conversation_participants 
            WHERE conversation_id = ? AND user_id = ?
        ");
        $stmt->execute([$conversation_id, $user_id]);
        if (!$stmt->fetch()) {
            json_response(["error" => "You are not a participant in this conversation"], 403);
        }
        
        // Mark messages as read
        $stmt = $pdo->prepare("
            UPDATE messages SET is_read = true 
            WHERE conversation_id = ? AND sender_id != ? AND is_read = false
        ");
        $stmt->execute([$conversation_id, $user_id]);
        
        // Get messages
        $stmt = $pdo->prepare("
            SELECT m.*, u.username, u.full_name, u.avatar_url,
                   (SELECT reaction FROM message_reactions WHERE message_id = m.id AND user_id = ?) as my_reaction
            FROM messages m
            JOIN users u ON m.sender_id = u.id
            WHERE m.conversation_id = ?
            AND (m.expires_at IS NULL OR m.expires_at > NOW())
            ORDER BY m.created_at ASC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $conversation_id, $limit, $offset]);
        $messages = $stmt->fetchAll();
        
        json_response([
            "success" => true,
            "conversation_id" => $conversation_id,
            "messages" => $messages,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
}

// POST - Create conversation, send message, or add reaction
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'message'; // 'conversation', 'message', 'reaction', 'typing'
    
    // Create new conversation
    if ($action === 'conversation') {
        $target_username = $input['username'] ?? null;
        $is_group = $input['is_group'] ?? false;
        $group_name = $input['group_name'] ?? null;
        $participants = $input['participants'] ?? []; // array of usernames
        
        if (!$is_group && !$target_username) {
            json_response(["error" => "Username is required for direct message"], 400);
        }
        
        if ($is_group && empty($participants)) {
            json_response(["error" => "Participants are required for group chat"], 400);
        }
        
        // Create conversation
        $stmt = $pdo->prepare("
            INSERT INTO conversations (is_group, group_name, created_at) 
            VALUES (?, ?, NOW())
            RETURNING id
        ");
        $stmt->execute([$is_group, $group_name]);
        $conversation_id = $stmt->fetchColumn();
        
        // Add participants
        $participant_ids = [$user_id];
        
        if (!$is_group) {
            // Get target user ID
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$target_username]);
            $target = $stmt->fetch();
            if (!$target) {
                json_response(["error" => "User not found"], 404);
            }
            $participant_ids[] = $target['id'];
        } else {
            // Add all participants for group chat
            $placeholders = implode(',', array_fill(0, count($participants), '?'));
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username IN ($placeholders)");
            $stmt->execute($participants);
            $group_participants = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $participant_ids = array_merge($participant_ids, $group_participants);
        }
        
        $participant_ids = array_unique($participant_ids);
        
        foreach ($participant_ids as $pid) {
            $stmt = $pdo->prepare("
                INSERT INTO conversation_participants (conversation_id, user_id, joined_at) 
                VALUES (?, ?, NOW())
            ");
            $stmt->execute([$conversation_id, $pid]);
        }
        
        json_response([
            "success" => true,
            "message" => "Conversation created successfully",
            "conversation_id" => $conversation_id
        ]);
    }
    
    // Send a message
    if ($action === 'message') {
        $conversation_id = $input['conversation_id'] ?? null;
        $content = trim($input['content'] ?? '');
        $message_type = $input['message_type'] ?? 'text'; // text, image, voice
        $reply_to_message_id = $input['reply_to_message_id'] ?? null;
        $is_disappearing = $input['is_disappearing'] ?? false;
        
        if (!$conversation_id) {
            json_response(["error" => "Conversation ID is required"], 400);
        }
        
        if ($message_type === 'text' && empty($content)) {
            json_response(["error" => "Message content cannot be empty"], 400);
        }
        
        // Check if user is in the conversation
        $stmt = $pdo->prepare("
            SELECT id FROM conversation_participants 
            WHERE conversation_id = ? AND user_id = ?
        ");
        $stmt->execute([$conversation_id, $user_id]);
        if (!$stmt->fetch()) {
            json_response(["error" => "You are not a participant in this conversation"], 403);
        }
        
        $expires_at = $is_disappearing ? "NOW() + INTERVAL '24 hours'" : null;
        
        $stmt = $pdo->prepare("
            INSERT INTO messages (conversation_id, sender_id, message_type, content, reply_to_message_id, is_disappearing, expires_at, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, " . ($expires_at ?: "NULL") . ", NOW())
            RETURNING id
        ");
        $stmt->execute([$conversation_id, $user_id, $message_type, $content, $reply_to_message_id, $is_disappearing]);
        $message_id = $stmt->fetchColumn();
        
        // Get other participants for notifications
        $stmt = $pdo->prepare("
            SELECT user_id FROM conversation_participants 
            WHERE conversation_id = ? AND user_id != ?
        ");
        $stmt->execute([$conversation_id, $user_id]);
        $other_participants = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($other_participants as $recipient_id) {
            $stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, type, from_user_id, message_id, content, created_at)
                VALUES (?, 'message', ?, ?, ?, NOW())
            ");
            $stmt->execute([$recipient_id, $user_id, $message_id, "sent you a message"]);
        }
        
        json_response([
            "success" => true,
            "message" => "Message sent successfully",
            "message_id" => $message_id
        ]);
    }
    
    // Add reaction to message
    if ($action === 'reaction') {
        $message_id = $input['message_id'] ?? null;
        $reaction = $input['reaction'] ?? null;
        
        if (!$message_id || !$reaction) {
            json_response(["error" => "Message ID and reaction are required"], 400);
        }
        
        if (strlen($reaction) > 10) {
            json_response(["error" => "Reaction too long"], 400);
        }
        
        // Upsert reaction
        $stmt = $pdo->prepare("
            INSERT INTO message_reactions (message_id, user_id, reaction, created_at) 
            VALUES (?, ?, ?, NOW())
            ON CONFLICT (message_id, user_id) DO UPDATE SET reaction = EXCLUDED.reaction
        ");
        $stmt->execute([$message_id, $user_id, $reaction]);
        
        json_response(["success" => true, "message" => "Reaction added"]);
    }
    
    // Typing indicator
    if ($action === 'typing') {
        $conversation_id = $input['conversation_id'] ?? null;
        $is_typing = $input['is_typing'] ?? true;
        
        // This would typically be handled via WebSocket
        // For now, just return success
        json_response(["success" => true, "is_typing" => $is_typing]);
    }
    
    json_response(["error" => "Invalid action"], 400);
}

// DELETE - Delete conversation or message
if ($request_method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $conversation_id = $input['conversation_id'] ?? null;
    $message_id = $input['message_id'] ?? null;
    
    if ($conversation_id) {
        // Check if user is in the conversation
        $stmt = $pdo->prepare("
            SELECT id FROM conversation_participants 
            WHERE conversation_id = ? AND user_id = ?
        ");
        $stmt->execute([$conversation_id, $user_id]);
        if (!$stmt->fetch()) {
            json_response(["error" => "You are not a participant in this conversation"], 403);
        }
        
        // Remove user from conversation
        $stmt = $pdo->prepare("DELETE FROM conversation_participants WHERE conversation_id = ? AND user_id = ?");
        $stmt->execute([$conversation_id, $user_id]);
        
        // If no participants left, delete conversation
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM conversation_participants WHERE conversation_id = ?");
        $stmt->execute([$conversation_id]);
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            $stmt = $pdo->prepare("DELETE FROM conversations WHERE id = ?");
            $stmt->execute([$conversation_id]);
        }
        
        json_response(["success" => true, "message" => "Left conversation"]);
    }
    
    if ($message_id) {
        // Check if user owns the message
        $stmt = $pdo->prepare("SELECT sender_id FROM messages WHERE id = ?");
        $stmt->execute([$message_id]);
        $message = $stmt->fetch();
        
        if (!$message) {
            json_response(["error" => "Message not found"], 404);
        }
        
        if ($message['sender_id'] != $user_id) {
            json_response(["error" => "You can only delete your own messages"], 403);
        }
        
        $stmt = $pdo->prepare("DELETE FROM messages WHERE id = ?");
        $stmt->execute([$message_id]);
        
        json_response(["success" => true, "message" => "Message deleted"]);
    }
    
    json_response(["error" => "Conversation ID or Message ID required"], 400);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>