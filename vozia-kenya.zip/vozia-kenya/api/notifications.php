<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Fetch notifications
if ($request_method === 'GET') {
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    $type = $_GET['type'] ?? 'all'; // 'all', 'unread'
    
    // Get unread count first
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM notifications 
        WHERE user_id = ? AND is_read = false
    ");
    $stmt->execute([$user_id]);
    $unread_count = $stmt->fetchColumn();
    
    // Build query
    $sql = "
        SELECT n.*, 
               u.username as from_username, 
               u.full_name as from_full_name, 
               u.avatar_url as from_avatar_url,
               u.is_verified as from_is_verified,
               p.image_url as post_image,
               c.content as comment_content,
               s.image_url as story_image,
               m.content as message_content
        FROM notifications n
        LEFT JOIN users u ON n.from_user_id = u.id
        LEFT JOIN posts p ON n.post_id = p.id
        LEFT JOIN comments c ON n.comment_id = c.id
        LEFT JOIN stories s ON n.story_id = s.id
        LEFT JOIN messages m ON n.message_id = m.id
        WHERE n.user_id = ?
    ";
    
    if ($type === 'unread') {
        $sql .= " AND n.is_read = false";
    }
    
    $sql .= " ORDER BY n.created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $pdo->prepare($sql);
    $params = [$user_id, $limit, $offset];
    if ($type === 'unread') {
        $params = [$user_id, $limit, $offset];
    }
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();
    
    // Format notifications for display
    foreach ($notifications as &$notif) {
        $notif['time_ago'] = time_ago($notif['created_at']);
        
        // Generate display text based on type
        switch ($notif['type']) {
            case 'like':
                $notif['display_text'] = "{$notif['from_username']} liked your post";
                break;
            case 'comment':
                $notif['display_text'] = "{$notif['from_username']} commented: " . substr($notif['comment_content'], 0, 50);
                break;
            case 'follow':
                $notif['display_text'] = "{$notif['from_username']} started following you";
                break;
            case 'mention':
                $notif['display_text'] = "{$notif['from_username']} mentioned you in a post";
                break;
            case 'message':
                $notif['display_text'] = "{$notif['from_username']} sent you a message";
                break;
            case 'story_reply':
                $notif['display_text'] = "{$notif['from_username']} replied to your story";
                break;
            case 'story_mention':
                $notif['display_text'] = "{$notif['from_username']} mentioned you in a story";
                break;
            case 'verification_response':
                $notif['display_text'] = $notif['content'];
                break;
            case 'withdrawal_response':
                $notif['display_text'] = $notif['content'];
                break;
            case 'post_share':
                $notif['display_text'] = "{$notif['from_username']} shared your post";
                break;
            case 'guide_mention':
                $notif['display_text'] = "{$notif['from_username']} mentioned you in a guide";
                break;
            case 'collab':
                $notif['display_text'] = "{$notif['from_username']} " . $notif['content'];
                break;
            case 'system':
                $notif['display_text'] = $notif['content'];
                break;
            default:
                $notif['display_text'] = $notif['content'];
        }
    }
    
    json_response([
        "success" => true,
        "notifications" => $notifications,
        "unread_count" => (int)$unread_count,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// POST - Mark notification as read
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $notification_id = $input['notification_id'] ?? null;
    $mark_all = $input['mark_all'] ?? false;
    
    if ($mark_all) {
        // Mark all as read
        $stmt = $pdo->prepare("
            UPDATE notifications SET is_read = true 
            WHERE user_id = ? AND is_read = false
        ");
        $stmt->execute([$user_id]);
        
        json_response(["success" => true, "message" => "All notifications marked as read"]);
    }
    
    if ($notification_id) {
        // Mark single notification as read
        $stmt = $pdo->prepare("
            UPDATE notifications SET is_read = true 
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$notification_id, $user_id]);
        
        json_response(["success" => true, "message" => "Notification marked as read"]);
    }
    
    json_response(["error" => "Notification ID or mark_all flag required"], 400);
}

// DELETE - Delete notification
if ($request_method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $notification_id = $input['notification_id'] ?? null;
    $delete_all = $input['delete_all'] ?? false;
    
    if ($delete_all) {
        // Delete all notifications
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
        $stmt->execute([$user_id]);
        
        json_response(["success" => true, "message" => "All notifications deleted"]);
    }
    
    if ($notification_id) {
        // Delete single notification
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
        $stmt->execute([$notification_id, $user_id]);
        
        json_response(["success" => true, "message" => "Notification deleted"]);
    }
    
    json_response(["error" => "Notification ID or delete_all flag required"], 400);
}

// Helper function to calculate time ago
function time_ago($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return $diff . ' seconds ago';
    } elseif ($diff < 3600) {
        return floor($diff / 60) . ' minutes ago';
    } elseif ($diff < 86400) {
        return floor($diff / 3600) . ' hours ago';
    } elseif ($diff < 604800) {
        return floor($diff / 86400) . ' days ago';
    } elseif ($diff < 2592000) {
        return floor($diff / 604800) . ' weeks ago';
    } else {
        return date('M j, Y', $timestamp);
    }
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>