<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Fetch profile (own or by username)
if ($request_method === 'GET') {
    $username = $_GET['username'] ?? null;
    $target_user_id = null;
    
    if ($username) {
        // Get profile by username
        $stmt = $pdo->prepare("
            SELECT id, username, email, full_name, bio, avatar_url, website, 
                   is_verified, is_private, is_professional, professional_category, 
                   created_at, last_login
            FROM users 
            WHERE username = ?
        ");
        $stmt->execute([$username]);
        $profile = $stmt->fetch();
        
        if (!$profile) {
            json_response(["error" => "User not found"], 404);
        }
        $target_user_id = $profile['id'];
    } else {
        // Get own profile
        $stmt = $pdo->prepare("
            SELECT id, username, email, full_name, bio, avatar_url, website, 
                   phone_number, is_verified, is_private, is_professional, professional_category, 
                   created_at, last_login
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$user_id]);
        $profile = $stmt->fetch();
        $target_user_id = $user_id;
    }
    
    // Get follower counts
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE following_id = ? AND is_approved = true");
    $stmt->execute([$target_user_id]);
    $followers_count = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE follower_id = ? AND is_approved = true");
    $stmt->execute([$target_user_id]);
    $following_count = $stmt->fetchColumn();
    
    // Get posts count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE user_id = ?");
    $stmt->execute([$target_user_id]);
    $posts_count = $stmt->fetchColumn();
    
    // Check if current user follows this profile
    $stmt = $pdo->prepare("
        SELECT id FROM followers 
        WHERE follower_id = ? AND following_id = ? AND is_approved = true
    ");
    $stmt->execute([$user_id, $target_user_id]);
    $is_following = $stmt->fetch() ? true : false;
    
    // Check if current user is blocked
    $stmt = $pdo->prepare("
        SELECT id FROM blocked_users 
        WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)
    ");
    $stmt->execute([$user_id, $target_user_id, $target_user_id, $user_id]);
    $is_blocked = $stmt->fetch() ? true : false;
    
    // Check if profile is private and user doesn't follow
    $can_view = true;
    if ($profile['is_private'] && $target_user_id != $user_id && !$is_following) {
        $can_view = false;
    }
    
    // Get posts for profile grid (only if can view)
    $posts = [];
    if ($can_view && !$is_blocked) {
        $stmt = $pdo->prepare("
            SELECT id, image_url, caption, likes_count, comments_count, created_at,
                   is_carousel, carousel_images, collab_user_id, location
            FROM posts 
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$target_user_id]);
        $posts = $stmt->fetchAll();
    }
    
    // Get stories (only if can view)
    $stories = [];
    if ($can_view && !$is_blocked) {
        $stmt = $pdo->prepare("
            SELECT id, image_url, caption, created_at, expires_at
            FROM stories 
            WHERE user_id = ? AND expires_at > NOW()
            ORDER BY created_at DESC
        ");
        $stmt->execute([$target_user_id]);
        $stories = $stmt->fetchAll();
    }
    
    // Get highlights
    $stmt = $pdo->prepare("
        SELECT h.*, 
               (SELECT image_url FROM highlight_stories hs JOIN stories s ON hs.story_id = s.id WHERE hs.highlight_id = h.id LIMIT 1) as cover_image
        FROM highlights h
        WHERE h.user_id = ?
    ");
    $stmt->execute([$target_user_id]);
    $highlights = $stmt->fetchAll();
    
    // Get monetization status (only for own profile)
    $monetization = null;
    if ($target_user_id == $user_id) {
        $stmt = $pdo->prepare("
            SELECT is_monetization_unlocked, total_points, total_earnings_kes, lifetime_likes_earned,
                   followers_at_unlock, views_at_unlock, unlocked_at
            FROM user_monetization 
            WHERE user_id = ?
        ");
        $stmt->execute([$user_id]);
        $monetization = $stmt->fetch();
    }
    
    json_response([
        "success" => true,
        "profile" => $profile,
        "stats" => [
            "followers_count" => (int)$followers_count,
            "following_count" => (int)$following_count,
            "posts_count" => (int)$posts_count,
            "stories_count" => count($stories)
        ],
        "is_following" => $is_following,
        "is_blocked" => $is_blocked,
        "can_view" => $can_view,
        "posts" => $posts,
        "stories" => $stories,
        "highlights" => $highlights,
        "monetization" => $monetization
    ]);
}

// PUT - Update profile
if ($request_method === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $full_name = $input['full_name'] ?? null;
    $bio = $input['bio'] ?? null;
    $website = $input['website'] ?? null;
    $is_private = isset($input['is_private']) ? (bool)$input['is_private'] : null;
    $is_professional = isset($input['is_professional']) ? (bool)$input['is_professional'] : null;
    $professional_category = $input['professional_category'] ?? null;
    
    // Build update query dynamically
    $updates = [];
    $params = [];
    
    if ($full_name !== null) {
        $updates[] = "full_name = ?";
        $params[] = $full_name;
    }
    if ($bio !== null) {
        $updates[] = "bio = ?";
        $params[] = $bio;
    }
    if ($website !== null) {
        $updates[] = "website = ?";
        $params[] = $website;
    }
    if ($is_private !== null) {
        $updates[] = "is_private = ?";
        $params[] = $is_private;
    }
    if ($is_professional !== null) {
        $updates[] = "is_professional = ?";
        $params[] = $is_professional;
    }
    if ($professional_category !== null) {
        $updates[] = "professional_category = ?";
        $params[] = $professional_category;
    }
    
    if (empty($updates)) {
        json_response(["error" => "No fields to update"], 400);
    }
    
    $updates[] = "updated_at = NOW()";
    $params[] = $user_id;
    
    $sql = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    json_response(["success" => true, "message" => "Profile updated successfully"]);
}

// POST - Update avatar (image upload)
if ($request_method === 'POST' && isset($_SERVER['HTTP_X_ACTION']) && $_SERVER['HTTP_X_ACTION'] === 'avatar') {
    if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        json_response(["error" => "Avatar image is required"], 400);
    }
    
    $avatar = $_FILES['avatar'];
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    
    if (!in_array($avatar['type'], $allowed_types)) {
        json_response(["error" => "Only JPG, PNG, and WEBP images are allowed"], 400);
    }
    
    // TODO: Upload to Cloudinary
    // For now, store as base64
    $image_data = base64_encode(file_get_contents($avatar['tmp_name']));
    $avatar_url = "data:" . $avatar['type'] . ";base64," . $image_data;
    
    $stmt = $pdo->prepare("UPDATE users SET avatar_url = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$avatar_url, $user_id]);
    
    json_response([
        "success" => true,
        "message" => "Avatar updated successfully",
        "avatar_url" => $avatar_url
    ]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>