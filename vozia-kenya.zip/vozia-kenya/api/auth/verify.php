<?php
// Allow GET and POST
$token = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = $_GET['token'] ?? '';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $token = $input['token'] ?? '';
} else {
    json_response(["error" => "Method not allowed"], 405);
}

if (empty($token)) {
    json_response(["error" => "Verification token is required"], 400);
}

// Find the verification token
$stmt = $pdo->prepare("
    SELECT user_id, email, expires_at 
    FROM email_verifications 
    WHERE token = ? AND expires_at > NOW()
");
$stmt->execute([$token]);
$verification = $stmt->fetch();

if (!$verification) {
    json_response(["error" => "Invalid or expired verification token"], 400);
}

// Update user as verified
$stmt = $pdo->prepare("UPDATE users SET is_verified = true WHERE id = ?");
$stmt->execute([$verification['user_id']]);

// Delete the verification token
$stmt = $pdo->prepare("DELETE FROM email_verifications WHERE token = ?");
$stmt->execute([$token]);

// Generate session token for auto-login
$session_token = bin2hex(random_bytes(32));

// Delete old sessions
$stmt = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?");
$stmt->execute([$verification['user_id']]);

// Create new session
$stmt = $pdo->prepare("
    INSERT INTO user_sessions (user_id, session_token, expires_at, created_at, last_activity) 
    VALUES (?, ?, NOW() + INTERVAL '30 days', NOW(), NOW())
");
$stmt->execute([$verification['user_id'], $session_token]);

// Get user data
$stmt = $pdo->prepare("
    SELECT id, username, email, full_name, avatar_url, bio, is_verified 
    FROM users WHERE id = ?
");
$stmt->execute([$verification['user_id']]);
$user = $stmt->fetch();

json_response([
    "success" => true,
    "message" => "Email verified successfully",
    "session_token" => $session_token,
    "user" => $user
]);
?>