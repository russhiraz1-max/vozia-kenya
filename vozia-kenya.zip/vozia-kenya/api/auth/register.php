<?php
// Allow POST only
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(["error" => "Method not allowed"], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$username = trim($input['username'] ?? '');
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';
$full_name = trim($input['full_name'] ?? '');
$phone_number = trim($input['phone_number'] ?? '');

// Validate input
if (empty($username) || empty($email) || empty($password)) {
    json_response(["error" => "Username, email, and password are required"], 400);
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(["error" => "Invalid email format"], 400);
}

// Validate username (alphanumeric + underscore)
if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
    json_response(["error" => "Username must be 3-50 characters and contain only letters, numbers, and underscore"], 400);
}

// Validate password strength (min 6 characters)
if (strlen($password) < 6) {
    json_response(["error" => "Password must be at least 6 characters"], 400);
}

// Check if user exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
$stmt->execute([$email, $username]);
if ($stmt->fetch()) {
    json_response(["error" => "User with this email or username already exists"], 409);
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Generate verification token
$verification_token = bin2hex(random_bytes(32));

// Insert user
$stmt = $pdo->prepare("
    INSERT INTO users (username, email, password_hash, full_name, phone_number, created_at) 
    VALUES (?, ?, ?, ?, ?, NOW())
    RETURNING id
");
$stmt->execute([$username, $email, $hashed_password, $full_name, $phone_number]);
$user_id = $stmt->fetchColumn();

// Store verification token
$stmt = $pdo->prepare("
    INSERT INTO email_verifications (user_id, email, token, expires_at) 
    VALUES (?, ?, ?, NOW() + INTERVAL '24 hours')
");
$stmt->execute([$user_id, $email, $verification_token]);

// Create user session
$session_token = bin2hex(random_bytes(32));
$stmt = $pdo->prepare("
    INSERT INTO user_sessions (user_id, session_token, expires_at, created_at) 
    VALUES (?, ?, NOW() + INTERVAL '30 days', NOW())
");
$stmt->execute([$user_id, $session_token]);

// TODO: Send verification email via Resend API
// For now, return success with verification link
$verification_link = "https://vozia-kenya-api.onrender.com/api/auth/verify?token=" . $verification_token;

json_response([
    "success" => true,
    "message" => "User created successfully. Please verify your email.",
    "user_id" => $user_id,
    "username" => $username,
    "session_token" => $session_token,
    "verification_link" => $verification_link
], 201);
?>