<?php
// Allow POST only
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(["error" => "Method not allowed"], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

// Validate input
if (empty($email) || empty($password)) {
    json_response(["error" => "Email and password are required"], 400);
}

// Get user by email or username
$stmt = $pdo->prepare("
    SELECT id, username, email, password_hash, full_name, avatar_url, bio, website, 
           is_verified, is_private, is_professional, professional_category, created_at
    FROM users 
    WHERE email = ? OR username = ?
");
$stmt->execute([$email, $email]);
$user = $stmt->fetch();

if (!$user) {
    json_response(["error" => "Invalid email or password"], 401);
}

// Verify password
if (!password_verify($password, $user['password_hash'])) {
    json_response(["error" => "Invalid email or password"], 401);
}

// Check if email is verified
if (!$user['is_verified']) {
    // Check if verification token exists and is not expired
    $stmt = $pdo->prepare("
        SELECT token FROM email_verifications 
        WHERE user_id = ? AND expires_at > NOW()
    ");
    $stmt->execute([$user['id']]);
    $verification = $stmt->fetch();
    
    json_response([
        "error" => "Email not verified",
        "user_id" => $user['id'],
        "email" => $user['email'],
        "needs_verification" => true
    ], 403);
}

// Generate new session token
$session_token = bin2hex(random_bytes(32));

// Delete old sessions for this user
$stmt = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?");
$stmt->execute([$user['id']]);

// Create new session
$stmt = $pdo->prepare("
    INSERT INTO user_sessions (user_id, session_token, expires_at, created_at, last_activity) 
    VALUES (?, ?, NOW() + INTERVAL '30 days', NOW(), NOW())
");
$stmt->execute([$user['id'], $session_token]);

// Update last login
$stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
$stmt->execute([$user['id']]);

// Remove password hash from response
unset($user['password_hash']);

// Get followers count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE following_id = ?");
$stmt->execute([$user['id']]);
$followers_count = $stmt->fetchColumn();

// Get following count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE follower_id = ?");
$stmt->execute([$user['id']]);
$following_count = $stmt->fetchColumn();

// Get posts count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE user_id = ?");
$stmt->execute([$user['id']]);
$posts_count = $stmt->fetchColumn();

// Check monetization status
$stmt = $pdo->prepare("
    SELECT is_monetization_unlocked, total_points, total_earnings_kes 
    FROM user_monetization WHERE user_id = ?
");
$stmt->execute([$user['id']]);
$monetization = $stmt->fetch();

json_response([
    "success" => true,
    "message" => "Login successful",
    "session_token" => $session_token,
    "user" => $user,
    "stats" => [
        "followers_count" => (int)$followers_count,
        "following_count" => (int)$following_count,
        "posts_count" => (int)$posts_count
    ],
    "monetization" => $monetization ? [
        "is_unlocked" => $monetization['is_monetization_unlocked'],
        "total_points" => (int)$monetization['total_points'],
        "total_earnings_kes" => (float)$monetization['total_earnings_kes']
    ] : [
        "is_unlocked" => false,
        "total_points" => 0,
        "total_earnings_kes" => 0
    ]
]);
?>