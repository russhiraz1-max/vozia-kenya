<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Check withdrawal status or history
if ($request_method === 'GET') {
    $withdrawal_id = $_GET['id'] ?? null;
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Single withdrawal status
    if ($withdrawal_id) {
        $stmt = $pdo->prepare("
            SELECT w.*, u.username, u.email
            FROM withdrawal_requests w
            JOIN users u ON w.user_id = u.id
            WHERE w.id = ? AND w.user_id = ?
        ");
        $stmt->execute([$withdrawal_id, $user_id]);
        $withdrawal = $stmt->fetch();
        
        if (!$withdrawal) {
            json_response(["error" => "Withdrawal request not found"], 404);
        }
        
        // Add status display text
        switch ($withdrawal['status']) {
            case 'pending':
                $withdrawal['status_text'] = 'Waiting for admin approval';
                break;
            case 'approved':
                $withdrawal['status_text'] = 'Approved - Payment will be sent shortly';
                break;
            case 'rejected':
                $withdrawal['status_text'] = 'Rejected - ' . ($withdrawal['admin_notes'] ?? 'Contact support');
                break;
            default:
                $withdrawal['status_text'] = $withdrawal['status'];
        }
        
        json_response(["success" => true, "withdrawal" => $withdrawal]);
    }
    
    // Get all withdrawals for user
    $stmt = $pdo->prepare("
        SELECT * FROM withdrawal_requests
        WHERE user_id = ?
        ORDER BY requested_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$user_id, $limit, $offset]);
    $withdrawals = $stmt->fetchAll();
    
    // Get totals by status
    $stmt = $pdo->prepare("
        SELECT status, COUNT(*) as count, COALESCE(SUM(amount_kes), 0) as total
        FROM withdrawal_requests
        WHERE user_id = ?
        GROUP BY status
    ");
    $stmt->execute([$user_id]);
    $totals = $stmt->fetchAll();
    
    $status_totals = [
        'pending' => 0,
        'approved' => 0,
        'rejected' => 0
    ];
    foreach ($totals as $total) {
        $status_totals[$total['status']] = [
            'count' => (int)$total['count'],
            'total' => (float)$total['total']
        ];
    }
    
    json_response([
        "success" => true,
        "withdrawals" => $withdrawals,
        "totals" => $status_totals,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// POST - Create new withdrawal request (handled in earnings.php)
// This is a fallback in case earnings.php is not used
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $amount_kes = (float)($input['amount_kes'] ?? 0);
    $payment_method = $input['payment_method'] ?? null;
    $payment_details = $input['payment_details'] ?? null;
    
    // Validate
    if ($amount_kes < 500) {
        json_response(["error" => "Minimum withdrawal amount is 500 KES"], 400);
    }
    
    if (!$payment_method || !$payment_details) {
        json_response(["error" => "Payment method and details are required"], 400);
    }
    
    // Check if monetization is unlocked
    $stmt = $pdo->prepare("
        SELECT is_monetization_unlocked, total_earnings_kes 
        FROM user_monetization WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $monetization = $stmt->fetch();
    
    if (!$monetization || !$monetization['is_monetization_unlocked']) {
        json_response(["error" => "Monetization not unlocked"], 403);
    }
    
    // Check balance
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(kes_value), 0) as total_earned
        FROM like_earnings WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $total_earned = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount_kes), 0) as total_withdrawn
        FROM withdrawal_requests WHERE user_id = ? AND status IN ('pending', 'approved')
    ");
    $stmt->execute([$user_id]);
    $total_withdrawn = $stmt->fetchColumn();
    
    $available = $total_earned - $total_withdrawn;
    
    if ($amount_kes > $available) {
        json_response(["error" => "Insufficient balance. Available: {$available} KES"], 400);
    }
    
    $points_to_deduct = $amount_kes * 500;
    
    // Get user details
    $stmt = $pdo->prepare("SELECT username, email, phone_number, full_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Create request
    $stmt = $pdo->prepare("
        INSERT INTO withdrawal_requests (
            user_id, amount_kes, points_deducted, payment_method, payment_details,
            full_name, email, phone_number, reason, status, requested_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
        RETURNING id
    ");
    $stmt->execute([
        $user_id, $amount_kes, $points_to_deduct, $payment_method, $payment_details,
        $user['full_name'] ?? $user['username'], $user['email'], $user['phone_number'] ?? '',
        "Withdrawal request for {$amount_kes} KES via {$payment_method}"
    ]);
    $withdrawal_id = $stmt->fetchColumn();
    
    // Send to admin panel (simplified - in production, use cURL)
    $admin_panel_url = "https://chic-lily-42ff8e.netlify.app/api/withdrawals";
    
    // This would be a cURL request to the admin panel
    /*
    $ch = curl_init($admin_panel_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'withdrawal_id' => $withdrawal_id,
        'user_id' => $user_id,
        'username' => $user['username'],
        'amount_kes' => $amount_kes,
        'payment_method' => $payment_method,
        'payment_details' => $payment_details,
        'full_name' => $user['full_name'],
        'email' => $user['email'],
        'phone_number' => $user['phone_number']
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_exec($ch);
    curl_close($ch);
    */
    
    json_response([
        "success" => true,
        "message" => "Withdrawal request submitted. Waiting for admin approval.",
        "withdrawal_id" => $withdrawal_id,
        "amount_kes" => $amount_kes,
        "points_deducted" => $points_to_deduct,
        "status" => "pending"
    ], 201);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>