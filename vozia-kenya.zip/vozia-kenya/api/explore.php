<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Explore page (discover new content)
if ($request_method === 'GET') {
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    $category = $_GET['category'] ?? 'all'; // 'all', 'popular', 'recent', 'for_you'
    
    // Get IDs of users that the current user follows (to exclude from explore)
    $stmt = $pdo->prepare("SELECT following_id FROM followers WHERE follower_id = ? AND is_approved = true");
    $stmt->execute([$user_id]);
    $following_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $following_ids[] = $user_id; // Also exclude self
    
    $exclude_ids = implode(',', array_map('intval', $following_ids));
    
    if ($category === 'for_you') {
        // Personalized explore based on user's interests (hashtags and interactions)
        $stmt = $pdo->prepare("
            SELECT DISTINCT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   COALESCE((
                       SELECT COUNT(*) FROM explore_interactions 
                       WHERE post_id = p.id AND interaction_type IN ('like', 'comment', 'share')
                   ), 0) as engagement_score
            FROM posts p
            JOIN users u ON p.user_id = u.id
            LEFT JOIN post_hashtags ph ON p.id = ph.post_id
            WHERE p.user_id NOT IN ($exclude_ids)
            AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            ORDER BY engagement_score DESC, p.likes_count DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
    } 
    elseif ($category === 'popular') {
        // Most liked posts from last 7 days
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id NOT IN ($exclude_ids)
            AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            AND p.created_at > NOW() - INTERVAL '7 days'
            ORDER BY p.likes_count DESC, p.comments_count DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
    }
    elseif ($category === 'recent') {
        // Most recent posts
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id NOT IN ($exclude_ids)
            AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
    }
    else {
        // Default - mixed explore
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   RANDOM() as random_order
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id NOT IN ($exclude_ids)
            AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            ORDER BY random_order
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
    }
    
    // Get suggested users (people you may know)
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.full_name, u.avatar_url, u.is_verified,
               (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = u.id) as is_following,
               (SELECT COUNT(*) FROM followers WHERE following_id = u.id) as followers_count
        FROM users u
        WHERE u.id NOT IN ($exclude_ids)
        AND u.id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
        ORDER BY followers_count DESC, RANDOM()
        LIMIT 10
    ");
    $stmt->execute([$user_id, $user_id]);
    $suggested_users = $stmt->fetchAll();
    
    // Get trending hashtags
    $stmt = $pdo->prepare("
        SELECT h.tag, h.posts_count
        FROM hashtags h
        ORDER BY h.posts_count DESC
        LIMIT 20
    ");
    $stmt->execute();
    $trending_hashtags = $stmt->fetchAll();
    
    json_response([
        "success" => true,
        "explore_type" => $category,
        "posts" => $posts,
        "suggested_users" => $suggested_users,
        "trending_hashtags" => $trending_hashtags,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>