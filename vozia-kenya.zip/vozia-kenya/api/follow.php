<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// POST - Follow or unfollow a user
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $target_username = $input['username'] ?? null;
    $action = $input['action'] ?? 'follow'; // 'follow' or 'unfollow'
    
    if (!$target_username) {
        json_response(["error" => "Username is required"], 400);
    }
    
    // Get target user
    $stmt = $pdo->prepare("SELECT id, username, is_private FROM users WHERE username = ?");
    $stmt->execute([$target_username]);
    $target = $stmt->fetch();
    
    if (!$target) {
        json_response(["error" => "User not found"], 404);
    }
    
    $target_id = $target['id'];
    
    if ($target_id == $user_id) {
        json_response(["error" => "You cannot follow yourself"], 400);
    }
    
    if ($action === 'follow') {
        // Check if already following
        $stmt = $pdo->prepare("SELECT id FROM followers WHERE follower_id = ? AND following_id = ?");
        $stmt->execute([$user_id, $target_id]);
        
        if ($stmt->fetch()) {
            json_response(["error" => "Already following this user"], 400);
        }
        
        // Check if blocked
        $stmt = $pdo->prepare("
            SELECT id FROM blocked_users 
            WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)
        ");
        $stmt->execute([$user_id, $target_id, $target_id, $user_id]);
        if ($stmt->fetch()) {
            json_response(["error" => "Cannot follow this user due to block"], 403);
        }
        
        // If account is private, follow request needs approval
        $is_approved = !$target['is_private'];
        
        $stmt = $pdo->prepare("
            INSERT INTO followers (follower_id, following_id, is_approved, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$user_id, $target_id, $is_approved]);
        
        // Create notification
        $content = $is_approved ? "started following you" : "requested to follow you";
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, from_user_id, content, created_at)
            VALUES (?, 'follow', ?, ?, NOW())
        ");
        $stmt->execute([$target_id, $user_id, $content]);
        
        // Check monetization unlock requirements (100k followers, 100k views, verified)
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM followers WHERE following_id = ? AND is_approved = true
        ");
        $stmt->execute([$target_id]);
        $followers_count = $stmt->fetchColumn();
        
        // Get profile views (from daily_metrics)
        $stmt = $pdo->prepare("
            SELECT SUM(profile_views) as total_views FROM daily_metrics WHERE user_id = ?
        ");
        $stmt->execute([$target_id]);
        $views_result = $stmt->fetch();
        $total_views = $views_result['total_views'] ?? 0;
        
        // Get verification status
        $stmt = $pdo->prepare("SELECT is_verified FROM users WHERE id = ?");
        $stmt->execute([$target_id]);
        $user_data = $stmt->fetch();
        
        // Check if user meets monetization requirements
        if ($followers_count >= 100000 && $total_views >= 100000 && $user_data['is_verified']) {
            // Check if monetization already unlocked
            $stmt = $pdo->prepare("SELECT id FROM user_monetization WHERE user_id = ? AND is_monetization_unlocked = true");
            $stmt->execute([$target_id]);
            
            if (!$stmt->fetch()) {
                // Unlock monetization
                $stmt = $pdo->prepare("
                    INSERT INTO user_monetization (user_id, is_monetization_unlocked, unlocked_at, followers_at_unlock, views_at_unlock)
                    VALUES (?, true, NOW(), ?, ?)
                    ON CONFLICT (user_id) DO UPDATE SET 
                        is_monetization_unlocked = true, 
                        unlocked_at = NOW(),
                        followers_at_unlock = EXCLUDED.followers_at_unlock,
                        views_at_unlock = EXCLUDED.views_at_unlock
                ");
                $stmt->execute([$target_id, $followers_count, $total_views]);
                
                // Notify user that monetization is unlocked
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, type, from_user_id, content, created_at)
                    VALUES (?, 'system', ?, 'Congratulations! You have unlocked monetization. You can now earn points for likes.', NOW())
                ");
                $stmt->execute([$target_id, $user_id]);
            }
        }
        
        json_response([
            "success" => true, 
            "message" => $is_approved ? "Now following" : "Follow request sent",
            "is_approved" => $is_approved
        ]);
    } 
    elseif ($action === 'unfollow') {
        // Remove follow
        $stmt = $pdo->prepare("DELETE FROM followers WHERE follower_id = ? AND following_id = ?");
        $stmt->execute([$user_id, $target_id]);
        
        json_response(["success" => true, "message" => "Unfollowed successfully"]);
    } 
    else {
        json_response(["error" => "Invalid action. Use 'follow' or 'unfollow'"], 400);
    }
}

// GET - Get followers or following list
if ($request_method === 'GET') {
    $username = $_GET['username'] ?? null;
    $type = $_GET['type'] ?? 'followers'; // 'followers' or 'following'
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Get target user ID
    if ($username) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $target = $stmt->fetch();
        if (!$target) {
            json_response(["error" => "User not found"], 404);
        }
        $target_id = $target['id'];
    } else {
        $target_id = $user_id;
    }
    
    if ($type === 'followers') {
        // Get followers (people who follow this user)
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = u.id) as follows_back
            FROM followers f
            JOIN users u ON f.follower_id = u.id
            WHERE f.following_id = ? AND f.is_approved = true
            ORDER BY f.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $target_id, $limit, $offset]);
        $users = $stmt->fetchAll();
        
        // Get total count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE following_id = ? AND is_approved = true");
        $stmt->execute([$target_id]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "users" => $users,
            "total" => (int)$total,
            "type" => "followers"
        ]);
    } 
    elseif ($type === 'following') {
        // Get following (people this user follows)
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = u.id) as follows_back
            FROM followers f
            JOIN users u ON f.following_id = u.id
            WHERE f.follower_id = ? AND f.is_approved = true
            ORDER BY f.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $target_id, $limit, $offset]);
        $users = $stmt->fetchAll();
        
        // Get total count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE follower_id = ? AND is_approved = true");
        $stmt->execute([$target_id]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "users" => $users,
            "total" => (int)$total,
            "type" => "following"
        ]);
    } 
    else {
        json_response(["error" => "Invalid type. Use 'followers' or 'following'"], 400);
    }
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>