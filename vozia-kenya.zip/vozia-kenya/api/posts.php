<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Fetch posts
if ($request_method === 'GET') {
    $post_id = $_GET['id'] ?? null;
    $username = $_GET['username'] ?? null;
    $limit = min(50, (int)($_GET['limit'] ?? 10));
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Single post by ID
    if ($post_id) {
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        ");
        $stmt->execute([$user_id, $user_id, $post_id]);
        $post = $stmt->fetch();
        
        if (!$post) {
            json_response(["error" => "Post not found"], 404);
        }
        
        // Decode carousel images if present
        if ($post['is_carousel'] && $post['carousel_images']) {
            $post['carousel_images'] = json_decode($post['carousel_images'], true);
        }
        
        json_response(["success" => true, "post" => $post]);
    }
    
    // Posts by username (profile grid)
    if ($username) {
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE u.username = ?
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $username, $limit, $offset]);
        $posts = $stmt->fetchAll();
        
        foreach ($posts as &$post) {
            if ($post['is_carousel'] && $post['carousel_images']) {
                $post['carousel_images'] = json_decode($post['carousel_images'], true);
            }
        }
        
        // Get total count
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE u.username = ?
        ");
        $stmt->execute([$username]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "posts" => $posts,
            "total" => (int)$total,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    
    // Main feed - posts from followed users
    $stmt = $pdo->prepare("
        SELECT p.*, u.username, u.full_name, u.avatar_url,
               (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
               (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
               (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
               (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
        FROM posts p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN followers f ON f.following_id = p.user_id AND f.follower_id = ?
        WHERE f.follower_id IS NOT NULL OR p.user_id = ?
        ORDER BY p.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $limit, $offset]);
    $posts = $stmt->fetchAll();
    
    foreach ($posts as &$post) {
        if ($post['is_carousel'] && $post['carousel_images']) {
            $post['carousel_images'] = json_decode($post['carousel_images'], true);
        }
    }
    
    json_response(["success" => true, "posts" => $posts, "limit" => $limit, "offset" => $offset]);
}

// POST - Create new post (supports carousel/multiple images)
if ($request_method === 'POST') {
    $caption = $_POST['caption'] ?? '';
    $is_carousel = isset($_POST['is_carousel']) ? (bool)$_POST['is_carousel'] : false;
    $collab_user_id = $_POST['collab_user_id'] ?? null;
    $location = $_POST['location'] ?? null;
    
    $image_urls = [];
    
    if ($is_carousel && isset($_FILES['images'])) {
        // Handle multiple images for carousel
        $files = $_FILES['images'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
        
        foreach ($files['tmp_name'] as $key => $tmp_name) {
            if ($files['error'][$key] === UPLOAD_ERR_OK) {
                $type = $files['type'][$key];
                if (in_array($type, $allowed_types)) {
                    $image_data = base64_encode(file_get_contents($tmp_name));
                    $image_urls[] = "data:" . $type . ";base64," . $image_data;
                }
            }
        }
        
        if (empty($image_urls)) {
            json_response(["error" => "At least one valid image is required"], 400);
        }
        
        $main_image_url = $image_urls[0];
        $carousel_json = json_encode($image_urls);
        
        $stmt = $pdo->prepare("
            INSERT INTO posts (user_id, image_url, carousel_images, is_carousel, caption, collab_user_id, location, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            RETURNING id
        ");
        $stmt->execute([$user_id, $main_image_url, $carousel_json, $is_carousel, $caption, $collab_user_id, $location]);
        $post_id = $stmt->fetchColumn();
        
    } else {
        // Handle single image
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            json_response(["error" => "Image is required"], 400);
        }
        
        $image = $_FILES['image'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
        
        if (!in_array($image['type'], $allowed_types)) {
            json_response(["error" => "Only JPG, PNG, and WEBP images are allowed"], 400);
        }
        
        $image_data = base64_encode(file_get_contents($image['tmp_name']));
        $image_url = "data:" . $image['type'] . ";base64," . $image_data;
        
        $stmt = $pdo->prepare("
            INSERT INTO posts (user_id, image_url, is_carousel, caption, collab_user_id, location, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
            RETURNING id
        ");
        $stmt->execute([$user_id, $image_url, $is_carousel, $caption, $collab_user_id, $location]);
        $post_id = $stmt->fetchColumn();
    }
    
    // If collab post, create notification for collab user
    if ($collab_user_id && $collab_user_id != $user_id) {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, from_user_id, post_id, content, created_at)
            VALUES (?, 'collab', ?, ?, ?, NOW())
        ");
        $stmt->execute([$collab_user_id, $user_id, $post_id, "invited you to collaborate on a post"]);
    }
    
    json_response([
        "success" => true,
        "message" => "Post created successfully",
        "post_id" => $post_id,
        "is_carousel" => $is_carousel,
        "image_count" => count($image_urls) ?: 1
    ], 201);
}

// DELETE - Delete post
if ($request_method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $post_id = $input['post_id'] ?? null;
    
    if (!$post_id) {
        json_response(["error" => "Post ID is required"], 400);
    }
    
    // Check if user owns the post
    $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    
    if (!$post) {
        json_response(["error" => "Post not found"], 404);
    }
    
    if ($post['user_id'] != $user_id) {
        json_response(["error" => "You can only delete your own posts"], 403);
    }
    
    // Delete post (cascade will handle likes, comments, saves)
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
    
    json_response(["success" => true, "message" => "Post deleted successfully"]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>