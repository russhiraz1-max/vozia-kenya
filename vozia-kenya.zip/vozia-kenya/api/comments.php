<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Fetch comments for a post
if ($request_method === 'GET') {
    $post_id = $_GET['post_id'] ?? null;
    $comment_id = $_GET['comment_id'] ?? null;
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    if ($comment_id) {
        // Get single comment with replies
        $stmt = $pdo->prepare("
            SELECT c.*, u.username, u.full_name, u.avatar_url,
                   (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id) as likes_count,
                   (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND user_id = ?) as user_liked
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.id = ?
        ");
        $stmt->execute([$user_id, $comment_id]);
        $comment = $stmt->fetch();
        
        if (!$comment) {
            json_response(["error" => "Comment not found"], 404);
        }
        
        // Get replies
        $stmt = $pdo->prepare("
            SELECT c.*, u.username, u.full_name, u.avatar_url,
                   (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id) as likes_count,
                   (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND user_id = ?) as user_liked
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.parent_comment_id = ?
            ORDER BY c.created_at ASC
        ");
        $stmt->execute([$user_id, $comment_id]);
        $replies = $stmt->fetchAll();
        
        $comment['replies'] = $replies;
        
        json_response(["success" => true, "comment" => $comment]);
    }
    
    if (!$post_id) {
        json_response(["error" => "Post ID is required"], 400);
    }
    
    // Check if post exists
    $stmt = $pdo->prepare("SELECT id, user_id FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    
    if (!$post) {
        json_response(["error" => "Post not found"], 404);
    }
    
    // Get comments for post (top-level only, no replies)
    $stmt = $pdo->prepare("
        SELECT c.*, u.username, u.full_name, u.avatar_url,
               (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id) as likes_count,
               (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND user_id = ?) as user_liked,
               (SELECT COUNT(*) FROM comments WHERE parent_comment_id = c.id) as reply_count
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.post_id = ? AND c.parent_comment_id IS NULL
        ORDER BY c.is_pinned DESC, c.created_at ASC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$user_id, $post_id, $limit, $offset]);
    $comments = $stmt->fetchAll();
    
    // Get total count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM comments WHERE post_id = ? AND parent_comment_id IS NULL");
    $stmt->execute([$post_id]);
    $total = $stmt->fetchColumn();
    
    json_response([
        "success" => true,
        "comments" => $comments,
        "total" => (int)$total,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// POST - Create a new comment or reply
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $post_id = $input['post_id'] ?? null;
    $parent_comment_id = $input['parent_comment_id'] ?? null;
    $content = trim($input['content'] ?? '');
    
    if (!$post_id && !$parent_comment_id) {
        json_response(["error" => "Post ID is required"], 400);
    }
    
    if (empty($content)) {
        json_response(["error" => "Comment content cannot be empty"], 400);
    }
    
    if (strlen($content) > 2000) {
        json_response(["error" => "Comment cannot exceed 2000 characters"], 400);
    }
    
    // Get post owner if commenting on post
    $post_owner_id = null;
    if ($post_id) {
        $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id = ?");
        $stmt->execute([$post_id]);
        $post = $stmt->fetch();
        if (!$post) {
            json_response(["error" => "Post not found"], 404);
        }
        $post_owner_id = $post['user_id'];
    }
    
    // If replying to a comment, get the parent comment's post
    if ($parent_comment_id) {
        $stmt = $pdo->prepare("SELECT post_id, user_id FROM comments WHERE id = ?");
        $stmt->execute([$parent_comment_id]);
        $parent = $stmt->fetch();
        if (!$parent) {
            json_response(["error" => "Parent comment not found"], 404);
        }
        $post_id = $parent['post_id'];
        $post_owner_id = $parent['user_id'];
    }
    
    // Insert comment
    $stmt = $pdo->prepare("
        INSERT INTO comments (user_id, post_id, parent_comment_id, content, created_at, updated_at)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        RETURNING id
    ");
    $stmt->execute([$user_id, $post_id, $parent_comment_id, $content]);
    $comment_id = $stmt->fetchColumn();
    
    // Create notification for post owner (if not commenting on own post)
    if ($user_id != $post_owner_id) {
        $notification_content = $parent_comment_id ? "replied to your comment" : "commented on your post";
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, from_user_id, post_id, comment_id, content, created_at)
            VALUES (?, 'comment', ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$post_owner_id, $user_id, $post_id, $comment_id, $notification_content]);
    }
    
    // Get the created comment with user details
    $stmt = $pdo->prepare("
        SELECT c.*, u.username, u.full_name, u.avatar_url,
               0 as likes_count, 0 as user_liked, 0 as reply_count
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.id = ?
    ");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch();
    
    json_response([
        "success" => true,
        "message" => $parent_comment_id ? "Reply added successfully" : "Comment added successfully",
        "comment" => $comment
    ], 201);
}

// PUT - Update comment (edit)
if ($request_method === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);
    $comment_id = $input['comment_id'] ?? null;
    $content = trim($input['content'] ?? '');
    
    if (!$comment_id) {
        json_response(["error" => "Comment ID is required"], 400);
    }
    
    if (empty($content)) {
        json_response(["error" => "Comment content cannot be empty"], 400);
    }
    
    // Check if user owns the comment
    $stmt = $pdo->prepare("SELECT user_id FROM comments WHERE id = ?");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch();
    
    if (!$comment) {
        json_response(["error" => "Comment not found"], 404);
    }
    
    if ($comment['user_id'] != $user_id) {
        json_response(["error" => "You can only edit your own comments"], 403);
    }
    
    // Update comment
    $stmt = $pdo->prepare("UPDATE comments SET content = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$content, $comment_id]);
    
    json_response(["success" => true, "message" => "Comment updated successfully"]);
}

// DELETE - Delete comment
if ($request_method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $comment_id = $input['comment_id'] ?? null;
    
    if (!$comment_id) {
        json_response(["error" => "Comment ID is required"], 400);
    }
    
    // Check if user owns the comment OR owns the post
    $stmt = $pdo->prepare("
        SELECT c.user_id as comment_owner, p.user_id as post_owner 
        FROM comments c
        JOIN posts p ON c.post_id = p.id
        WHERE c.id = ?
    ");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch();
    
    if (!$comment) {
        json_response(["error" => "Comment not found"], 404);
    }
    
    if ($comment['comment_owner'] != $user_id && $comment['post_owner'] != $user_id) {
        json_response(["error" => "You can only delete your own comments or comments on your posts"], 403);
    }
    
    // Delete comment (cascade will handle comment_likes and replies)
    $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
    $stmt->execute([$comment_id]);
    
    json_response(["success" => true, "message" => "Comment deleted successfully"]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>