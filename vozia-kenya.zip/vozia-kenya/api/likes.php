<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// POST - Like or unlike a post
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $post_id = $input['post_id'] ?? null;
    $action = $input['action'] ?? 'like'; // 'like' or 'unlike'
    
    if (!$post_id) {
        json_response(["error" => "Post ID is required"], 400);
    }
    
    // Check if post exists and get post owner
    $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    
    if (!$post) {
        json_response(["error" => "Post not found"], 404);
    }
    
    $post_owner_id = $post['user_id'];
    
    if ($action === 'like') {
        // Check if already liked
        $stmt = $pdo->prepare("SELECT id FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->execute([$user_id, $post_id]);
        
        if (!$stmt->fetch()) {
            // Add like
            $stmt = $pdo->prepare("INSERT INTO likes (user_id, post_id, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$user_id, $post_id]);
            
            // Create notification for post owner (if not liking own post)
            if ($user_id != $post_owner_id) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, type, from_user_id, post_id, content, created_at)
                    VALUES (?, 'like', ?, ?, ?, NOW())
                ");
                $stmt->execute([$post_owner_id, $user_id, $post_id, "liked your post"]);
            }
            
            // EARNING SYSTEM: 1 like = 5 points = 0.010 KES
            // Check if post owner has monetization unlocked
            $stmt = $pdo->prepare("
                SELECT is_monetization_unlocked, total_points, total_earnings_kes 
                FROM user_monetization WHERE user_id = ?
            ");
            $stmt->execute([$post_owner_id]);
            $monetization = $stmt->fetch();
            
            $points_earned = 5;
            $kes_value = 0.010;
            
            if ($monetization && $monetization['is_monetization_unlocked']) {
                // Update user monetization totals
                $new_points = $monetization['total_points'] + $points_earned;
                $new_earnings = $monetization['total_earnings_kes'] + $kes_value;
                
                $stmt = $pdo->prepare("
                    UPDATE user_monetization 
                    SET total_points = ?, total_earnings_kes = ?, lifetime_likes_earned = lifetime_likes_earned + 1
                    WHERE user_id = ?
                ");
                $stmt->execute([$new_points, $new_earnings, $post_owner_id]);
                
                // Record individual like earning
                $stmt = $pdo->prepare("
                    INSERT INTO like_earnings (user_id, post_id, liker_id, points_earned, kes_value, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([$post_owner_id, $post_id, $user_id, $points_earned, $kes_value]);
            }
            
            json_response(["success" => true, "action" => "liked", "points_earned" => $points_earned, "kes_value" => $kes_value]);
        } else {
            json_response(["success" => false, "message" => "Already liked", "action" => "already_liked"]);
        }
    } 
    elseif ($action === 'unlike') {
        // Remove like
        $stmt = $pdo->prepare("DELETE FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->execute([$user_id, $post_id]);
        
        // Note: Points are NOT deducted when unliking (user keeps earnings)
        
        json_response(["success" => true, "action" => "unliked"]);
    } 
    else {
        json_response(["error" => "Invalid action. Use 'like' or 'unlike'"], 400);
    }
}

// GET - Check if user liked a specific post
if ($request_method === 'GET') {
    $post_id = $_GET['post_id'] ?? null;
    
    if ($post_id) {
        $stmt = $pdo->prepare("SELECT id FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->execute([$user_id, $post_id]);
        $is_liked = $stmt->fetch() ? true : false;
        
        json_response(["success" => true, "is_liked" => $is_liked]);
    }
    
    // Get all liked posts by user
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    $stmt = $pdo->prepare("
        SELECT p.*, u.username, u.full_name, u.avatar_url,
               (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
               (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count
        FROM likes l
        JOIN posts p ON l.post_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE l.user_id = ?
        ORDER BY l.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$user_id, $limit, $offset]);
    $liked_posts = $stmt->fetchAll();
    
    json_response(["success" => true, "liked_posts" => $liked_posts]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>