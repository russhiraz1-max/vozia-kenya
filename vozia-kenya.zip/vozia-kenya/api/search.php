<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Search users, posts, hashtags, locations
if ($request_method === 'GET') {
    $query = trim($_GET['q'] ?? '');
    $type = $_GET['type'] ?? 'all'; // 'all', 'users', 'posts', 'hashtags', 'locations'
    $limit = min(50, (int)($_GET['limit'] ?? 20));
    $offset = (int)($_GET['offset'] ?? 0);
    
    if (strlen($query) < 2) {
        json_response(["error" => "Search query must be at least 2 characters"], 400);
    }
    
    $search_pattern = '%' . $query . '%';
    $result = [];
    
    // Search users
    if ($type === 'all' || $type === 'users') {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.full_name, u.avatar_url, u.bio, u.is_verified, u.is_private,
                   (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = u.id) as is_following,
                   (SELECT COUNT(*) FROM followers WHERE following_id = u.id) as followers_count
            FROM users u
            WHERE u.username ILIKE ? OR u.full_name ILIKE ?
            AND u.id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            ORDER BY 
                CASE WHEN u.username ILIKE ? THEN 1 ELSE 2 END,
                followers_count DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $search_pattern, $search_pattern, $user_id, $query, $limit, $offset]);
        $result['users'] = $stmt->fetchAll();
    }
    
    // Search posts
    if ($type === 'all' || $type === 'posts') {
        $stmt = $pdo->prepare("
            SELECT p.id, p.image_url, p.caption, p.likes_count, p.comments_count, p.created_at,
                   u.username, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.caption ILIKE ?
            AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
            ORDER BY p.likes_count DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $search_pattern, $user_id, $limit, $offset]);
        $result['posts'] = $stmt->fetchAll();
    }
    
    // Search hashtags
    if ($type === 'all' || $type === 'hashtags') {
        $stmt = $pdo->prepare("
            SELECT h.tag, h.posts_count
            FROM hashtags h
            WHERE h.tag ILIKE ?
            ORDER BY h.posts_count DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$search_pattern, $limit, $offset]);
        $result['hashtags'] = $stmt->fetchAll();
    }
    
    // Search locations
    if ($type === 'all' || $type === 'locations') {
        $stmt = $pdo->prepare("
            SELECT l.id, l.name, l.posts_count
            FROM locations l
            WHERE l.name ILIKE ?
            ORDER BY l.posts_count DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$search_pattern, $limit, $offset]);
        $result['locations'] = $stmt->fetchAll();
    }
    
    // If type is specific, return just that array
    if ($type !== 'all') {
        $key = $type . 's';
        if ($type === 'hashtag') $key = 'hashtags';
        if ($type === 'location') $key = 'locations';
        json_response([
            "success" => true,
            "query" => $query,
            "type" => $type,
            "results" => $result[$key] ?? [],
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    
    json_response([
        "success" => true,
        "query" => $query,
        "results" => $result,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// POST - Search by hashtag specifically
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $hashtag = trim($input['hashtag'] ?? '');
    $limit = min(50, (int)($input['limit'] ?? 20));
    $offset = (int)($input['offset'] ?? 0);
    
    if (empty($hashtag)) {
        json_response(["error" => "Hashtag is required"], 400);
    }
    
    // Remove # if present
    $hashtag = ltrim($hashtag, '#');
    
    // Get hashtag ID
    $stmt = $pdo->prepare("SELECT id FROM hashtags WHERE tag = ?");
    $stmt->execute([$hashtag]);
    $hashtag_id = $stmt->fetchColumn();
    
    if (!$hashtag_id) {
        json_response(["success" => true, "hashtag" => $hashtag, "posts" => [], "total" => 0]);
    }
    
    // Get posts with this hashtag
    $stmt = $pdo->prepare("
        SELECT p.id, p.image_url, p.caption, p.likes_count, p.comments_count, p.created_at,
               u.username, u.avatar_url, u.is_verified,
               (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
               (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN post_hashtags ph ON p.id = ph.post_id
        WHERE ph.hashtag_id = ?
        AND p.user_id NOT IN (SELECT blocked_id FROM blocked_users WHERE blocker_id = ?)
        ORDER BY p.likes_count DESC, p.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$user_id, $user_id, $hashtag_id, $user_id, $limit, $offset]);
    $posts = $stmt->fetchAll();
    
    // Get total count
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM post_hashtags WHERE hashtag_id = ?
    ");
    $stmt->execute([$hashtag_id]);
    $total = $stmt->fetchColumn();
    
    json_response([
        "success" => true,
        "hashtag" => $hashtag,
        "posts" => $posts,
        "total" => (int)$total,
        "limit" => $limit,
        "offset" => $offset
    ]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>