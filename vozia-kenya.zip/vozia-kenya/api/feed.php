<?php
// Get authenticated user ID
$user_id = get_user_id($pdo);

if (!$user_id) {
    json_response(["error" => "Unauthorized. Please login."], 401);
}

$request_method = $_SERVER['REQUEST_METHOD'];

// GET - Main feed (posts from followed users)
if ($request_method === 'GET') {
    $limit = min(50, (int)($_GET['limit'] ?? 10));
    $offset = (int)($_GET['offset'] ?? 0);
    $type = $_GET['type'] ?? 'following'; // 'following', 'for_you', or 'trending'
    
    if ($type === 'following') {
        // Get posts from users that the current user follows
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = p.user_id) as is_following
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id IN (
                SELECT following_id FROM followers 
                WHERE follower_id = ? AND is_approved = true
            ) OR p.user_id = ?
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
        
        // Get total count
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM posts p
            WHERE p.user_id IN (
                SELECT following_id FROM followers 
                WHERE follower_id = ? AND is_approved = true
            ) OR p.user_id = ?
        ");
        $stmt->execute([$user_id, $user_id]);
        $total = $stmt->fetchColumn();
        
        json_response([
            "success" => true,
            "feed_type" => "following",
            "posts" => $posts,
            "total" => (int)$total,
            "limit" => $limit,
            "offset" => $offset
        ]);
    } 
    elseif ($type === 'for_you') {
        // Algorithm-based feed using explore_interactions
        // Get posts based on user's interactions (likes, comments, saves)
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   (SELECT COUNT(*) FROM followers WHERE follower_id = ? AND following_id = p.user_id) as is_following,
                   COALESCE((
                       SELECT COUNT(*) FROM explore_interactions 
                       WHERE post_id = p.id AND interaction_type IN ('like', 'comment', 'share')
                   ), 0) as engagement_score
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id NOT IN (
                SELECT blocked_id FROM blocked_users WHERE blocker_id = ?
            )
            ORDER BY engagement_score DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
        
        json_response([
            "success" => true,
            "feed_type" => "for_you",
            "posts" => $posts,
            "limit" => $limit,
            "offset" => $offset
        ]);
    } 
    elseif ($type === 'trending') {
        // Trending posts (most likes/comments in last 7 days)
        $stmt = $pdo->prepare("
            SELECT p.*, u.username, u.full_name, u.avatar_url, u.is_verified,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
                   (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count,
                   (SELECT COUNT(*) FROM saves WHERE post_id = p.id AND user_id = ?) as is_saved,
                   (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked,
                   (p.likes_count + p.comments_count) as total_engagement
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.created_at > NOW() - INTERVAL '7 days'
            ORDER BY total_engagement DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user_id, $user_id, $limit, $offset]);
        $posts = $stmt->fetchAll();
        
        json_response([
            "success" => true,
            "feed_type" => "trending",
            "posts" => $posts,
            "limit" => $limit,
            "offset" => $offset
        ]);
    }
    else {
        json_response(["error" => "Invalid feed type. Use 'following', 'for_you', or 'trending'"], 400);
    }
}

// POST - Track feed interaction for algorithm
if ($request_method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $post_id = $input['post_id'] ?? null;
    $interaction_type = $input['interaction_type'] ?? null; // 'view', 'like', 'comment', 'share', 'save'
    
    if (!$post_id || !$interaction_type) {
        json_response(["error" => "Post ID and interaction type are required"], 400);
    }
    
    $valid_types = ['view', 'like', 'comment', 'share', 'save'];
    if (!in_array($interaction_type, $valid_types)) {
        json_response(["error" => "Invalid interaction type"], 400);
    }
    
    // Record interaction for explore algorithm
    $stmt = $pdo->prepare("
        INSERT INTO explore_interactions (user_id, post_id, interaction_type, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$user_id, $post_id, $interaction_type]);
    
    json_response(["success" => true, "message" => "Interaction tracked"]);
}

// Method not allowed
json_response(["error" => "Method not allowed"], 405);
?>